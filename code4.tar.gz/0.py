import pickle as pkl
import networkx as nx
# n, g  = pkl.load(open('/home/sise/sda/gyj/NM/411data/wireshark-subgraph-0.pkl', 'rb'))
b = pkl.load(open('/home/sise/sda/gyj/NM/411data/seeds_kernel6/seed_vul_1__lpfc_els_rcv_lcb.pkl', 'rb'))
print('d')
# a.remove_node('Call@94')
# pkl.dump(a, open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/asn1_print_info-refine.pkl', 'wb'))
# n, g = pkl.load(open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/subgraph-noremove.pkl', 'rb'))

# for i in range(len(n)):
#     if n[i] == '369__read_keytab_file_Call@2694':
#         gi = g[i]
#         print('d')
# b = nx.DiGraph()
# b.add_edges_from([('Call@5d','Call@80')])
# b.remove_edges_from([('Call@5d','Call@8b'),('Call@80','Return@90'),('Call@5d','Call@8b')])
# # b.remove_nodes_from(['Return@90','Call@8b'])
# print('d')
# pkl.dump(b, open('/home/sise/sda/gyj/NM/411data/seeds_3/seed_vul3_0__lpass_platform_pcmops_open-refine.pkl', 'wb'))
