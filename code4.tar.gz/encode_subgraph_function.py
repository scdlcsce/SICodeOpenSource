import argparse
from config import parse_encoder
from gutils import g2feats, g_sample, gmerge
import utils
from tqdm import tqdm
import os
import pickle as pkl

input_dim = 300
wvec_dim = 276
opr_dim = 22

import time
import  torch
import  numpy as np
from modeldata100 import DiskDataSource
import models


def build_model(args):
    model = models.OrderEmbedder(args)
    model.to(utils.get_device())
    return model

seed = 123
np.random.seed(seed)
torch.random.manual_seed(seed)

with open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/kernel_cluster_276-ft.txt', 'r') as fp:
    ldict = eval(fp.read())

def build_model(args):
    model = models.OrderEmbedder(args)
    model.to(utils.get_device())
    return model

seed = 123
np.random.seed(seed)
torch.random.manual_seed(seed)


if __name__ == "__main__":
    pgraph = pkl.load(open('/home/sise/sda/gyj/NM/411data/kernel5_addr_pdg/7567__otx2vf_probe.pkl', 'rb'))
    for n in list(pgraph.nodes()):
        if 'MethodReturn' in n or 'Method' in n:
            pgraph.remove_node(n)
    apilist = [ni for ni in list(pgraph.nodes()) if pgraph.nodes()[ni]['type'] == 'api']
    for n in apilist:
        if n in ['Call@12c3']:
            print('d')
        subc = g_sample(pgraph ,n, 4, 'cfg')
        subcdg, subddg = g_sample(pgraph ,n, 4, 'pdg')
        if subc == None or subcdg == None or subddg == None:
            continue
        g = gmerge(n, subc, subcdg, subddg)
        if len(g.nodes()) < 3:
            continue
        if len(list(subc.edges())) == 0:
            continue
        feats, g = g2feats(g, input_dim, wvec_dim, ldict)


