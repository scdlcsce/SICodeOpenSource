import os

with open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/kernel517_code/list.txt') as fp:
    filelists = fp.readlines()

filelists = [l.strip()+'.c' for l in filelists]

with open('/home/sise/sda/gyj/NM/411data/log_invertkernel5_cc_cipher_exit2.txt') as fp:
    fnums = fp.readlines()
fnums = [int(f.split('__')[0]) for f in fnums]

for f in fnums:
    c = "git show "+ filelists[f] + '> /home/sise/sda/gyj/NM/graphdomain_openssl/tmplog'
    os.system(c)
    with open('/home/sise/sda/gyj/NM/graphdomain_openssl/tmplog') as fp:
        logfile = fp.readlines()
    if 'use after free' in logfile or 'use-after-free' in logfile:
        c = 'cp /home/sise/sda/gyj/NM/graphdomain_openssl/tmplog /home/sise/sda/gyj/NM/graphdomain_openssl/log/'+str(f)
        os.system(c)
        