import argparse
from config import parse_encoder
from gutils import g2feats, g_sample, gmerge
import utils
from tqdm import tqdm
import os
import pickle as pkl

input_dim = 300
wvec_dim = 276
opr_dim = 22

import time
import  torch
import  numpy as np
from modeldata100 import DiskDataSource
import models


def build_model(args):
    model = models.OrderEmbedder(args)
    model.to(utils.get_device())
    return model

seed = 123
np.random.seed(seed)
torch.random.manual_seed(seed)





def build_model(args):
    model = models.OrderEmbedder(args)
    model.to(utils.get_device())
    return model

seed = 123
np.random.seed(seed)
torch.random.manual_seed(seed)

model_path = '/home/sise/sda/gyj/NM/graphdomain_openssl/E21/ckpt/params_070_79n.pt'


if __name__ == "__main__":
    print(time.time())
    parser = (argparse.ArgumentParser(description='Order embedding arguments'))
    utils.parse_optimizer(parser)
    parse_encoder(parser)
    args = parser.parse_args()
    model = models.OrderEmbedder(args)
    model.to(utils.get_device())
    model.load_state_dict(torch.load(model_path))
    model.eval()


    for i in tqdm(range(0,33)):
        [namelist, emb_T, featslist] = pkl.load(open('/home/sise/sda/gyj/NM/kernel6new3/emb-{}.pkl'.format(i), 'rb'))
        [namelist, subgraphlist] = pkl.load(open('/home/sise/sda/gyj/NM/kernel6new3/subgraph-{}.pkl'.format(i), 'rb'))
        emb_S = []
        Sdata_source = DiskDataSource(subgraphlist)
        loaders = Sdata_source.gen_retrieval_loaders(len(subgraphlist), args.batch_size )
        for batch_i in tqdm(loaders):
            g = Sdata_source.gen_retrieval_batch(batch_i)
            with torch.no_grad():
                emb_g = model.emb_model(g)
            emb_S += emb_g
        emb_S = torch.stack(emb_S)
        emb_S = emb_S.cpu().detach()

        pkl.dump([namelist, emb_S, featslist], open('/home/sise/sda/gyj/NM/kernel6new3/E21-emb-{}.pkl'.format(i), 'wb'))
        # pkl.dump([namelist, subgraphlist], open('/home/sise/sda/gyj/NM/411data/nm-kernel5-subgraph-{}.pkl'.format(i), 'wb'))
    print(time.time())
