import  torch
import argparse
from config import parse_encoder
import models
from gutils import g2feats
import utils
from tqdm import tqdm
from tqdm import tqdm
import pickle as pkl
import numpy as np
input_dim = 300
wvec_dim = 276
opr_dim = 22
from modeldata100 import DiskDataSource
import time

g_seed = pkl.load(open('/home/sise/sda/gyj/NM/411data/727kernel/seed/seed6__s3c2410wdt_probe.pkl', 'rb'))
g_patch = pkl.load(open('/home/sise/sda/gyj/NM/411data/727kernel/seed/patch2__emac_tso_csum.pkl', 'rb'))
model_path = '/home/sise/sda/gyj/NM/graphdomain_openssl/E20/ckpt/params_070_79n.pt'
logpath_v = '/home/sise/sda/gyj/NM/411data/727kernel/log/s3c2410wdt_probe-v7-31.txt'
logpath_p = '/home/sise/sda/gyj/NM/411data/727kernel/log/emac_tso_csum-p2.txt'
with open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/kernel_cluster_276-ft.txt', 'r') as fp:
    ldict = eval(fp.read())

def build_model(args):
    model = models.OrderEmbedder(args)
    model.to(utils.get_device())
    return model

if __name__ == "__main__":
    print(time.time())
    feat_seed, g = g2feats(g_seed, input_dim, wvec_dim, ldict)
    feat_patch, g = g2feats(g_patch, input_dim, wvec_dim, ldict)
    parser = (argparse.ArgumentParser(description='Order embedding arguments'))
    utils.parse_optimizer(parser)
    parse_encoder(parser)
    args = parser.parse_args()

    model = models.OrderEmbedder(args)
    model.to(utils.get_device())
    model.load_state_dict(torch.load(model_path))
    model.eval()

    Sdata_source = DiskDataSource([g_seed])
    loaders = Sdata_source.gen_retrieval_loaders(1, 1)
    for batch_i in tqdm(loaders):
        v = Sdata_source.gen_retrieval_batch(batch_i)
        with torch.no_grad():
            emb_v = model.emb_model(v)

    Pdata_source = DiskDataSource([g_patch])
    loaders = Pdata_source.gen_retrieval_loaders(1, 1)
    for batch_i in tqdm(loaders):
        p = Pdata_source.gen_retrieval_batch(batch_i)
        with torch.no_grad():
            emb_p = model.emb_model(p)

    p_dict_all_v = {}
    p_dict_all_p = {}

    for i in tqdm(range(0,32)):
        # [namelist, emb_T, featslist] = pkl.load(open('/home/sise/sda/gyj/NM/emb-{}.pkl'.format(i), 'rb'))
        # [namelist, subgraphs] = pkl.load(open('/home/sise/sda/gyj/NM/subgraph-{}.pkl'.format(i), 'rb'))
        [namelist, emb_T, featslist] = pkl.load(open('/home/sise/sda/gyj/NM/kernel6new3/emb-{}.pkl'.format(i), 'rb'))
    
        featslist =np.asarray(featslist)
        # sizetarget = torch.tensor(np.sum(featslist, axis= -1)).to(torch.device("cuda:1"))
        idxs_v = np.where(np.min(featslist - feat_seed,axis = 1)>=0)[0]
        s_namelist_v = [namelist[i] for i in idxs_v.tolist()]
            
        v_seeds = emb_v.expand(emb_T.shape)
        raw_pred_seed = model.predict(emb_T.to(utils.get_device()), v_seeds)

        pred_v = [0 if raw_pred_seed[idx] > 500 else 1 for idx in range(int(raw_pred_seed.shape[0]))]

        p_dict_v = {namelist[idxp]:raw_pred_seed[idxp].item() for idxp, p in enumerate(pred_v) if (p ==1 and namelist[idxp] in s_namelist_v) }
        for k in p_dict_v.keys():
            p_dict_all_v[k] = p_dict_v[k]



        # idxs_p = np.where(np.min(featslist - feat_patch,axis = 1)>=0)[0]
        # s_namelist_p = [namelist[i] for i in idxs_p.tolist()]
            
        # v_patches = emb_p.expand(emb_T.shape)
        # raw_pred_patch = model.predict(emb_T.to(utils.get_device()), v_patches)

        # pred_p = [0 if raw_pred_patch[idx] > 500 else 1 for idx in range(int(raw_pred_patch.shape[0]))]

        # p_dict_p = {namelist[idxp]:raw_pred_patch[idxp].item() for idxp, p in enumerate(pred_p) if (p ==1 and namelist[idxp] in s_namelist_p) }
        # for k in p_dict_p.keys():
        #     p_dict_all_p[k] = p_dict_p[k]

        # pred = [0 if raw_pred_seed[idx]> 1000 else 1 for idx in range(int(raw_pred_seed.shape[0]))]
        # pred = [0 if (raw_pred_seed[idx] > 100 or raw_pred_patch[idx] > 25) else 1 for idx in range(int(raw_pred_seed.shape[0]))]
        # pred = [0 if (raw_pred_seed[idx] > 100 and invert_raw_pred_patch[idx] <= invert_raw_pred_seed[idx]) else 1 for idx in range(int(raw_pred_seed.shape[0]))]

        # p_dict = {namelist[idxp]:raw_pred_seed[idxp].item() for idxp, p in enumerate(pred) if (p ==1 and namelist[idxp] in s_namelist) }
        # for k in p_dict.keys():
        #     p_dict_all[k] = p_dict[k]
    
    p_dict_v = sorted(p_dict_all_v.items(), key=lambda d: d[1], reverse=False)[:1000]
    p_dict_p = sorted(p_dict_all_p.items(), key=lambda d: d[1], reverse=False)[:1000]

    p_func = []
    for p in p_dict_v:
        f = p[0].split('_Call@')[0]
        if not f in p_func:
            p_func.append(f)

    p_dict = [p[0]+','+str(p[1]) for p in p_dict_v]

    with open(logpath_v,'w')as fp:
        fp.write(str(p_dict)+'\n\n\n'+ str(p_func))
    print(time.time())

    # p_func = []
    # for p in p_dict_p:
    #     f = p[0].split('_Call@')[0]
    #     if not f in p_func:
    #         p_func.append(f)

    # p_dict = [p[0]+','+str(p[1]) for p in p_dict_p]

    # with open(logpath_p,'w')as fp:
    #     fp.write(str(p_dict)+'\n\n\n'+ str(p_func))
    # print(time.time())
    