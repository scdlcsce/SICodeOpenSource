import networkx as nx
import numpy as np

codetype = [ 
    '<operator>.assignment',
    '<operator>.assignmentPlus',
    '<operator>.assignmentMultiplication',
    '<operator>.assignmentDivision',
    '<operator>.assignmentMinus',
    '<operators>.assignmentAnd',
    '<operator>.assignmentAnd',
    '<operators>.assignmentOr',
    '<operators>.assignmentXor',
    '<operators>.assignmentModulo',
    '<operators>.assignmentExponentiation',
    '<operators>.assignmentArithmeticShiftRight',
    '<operators>.LogicalShifRight',
    '<operators>.assignmentShiftLeft',
    '<operator>.logicalNot',
    '<operator>.logicalOr',
    '<operator>.logicalAnd',
    '<operator>.equals',
    '<operator>.notEquals',
    '<operator>.indirectMemberAccess',
    '<operator>.computedMemberAccess',
    '<operator>.addressOf',
    '<operator>.cast',
    '<operator>.conditionalExpression',
    '<operator>.postIncrement',
    '<operator>.preIncrement',
    '<operator>.postDecrement',
    '<operator>.preDecrement',
    '<operator>.or',
    '<operator>.and',
    '<operator>.addition',
    '<operator>.subtraction',
    '<operator>.multiplication',
    '<operator>.division',
    '<operator>.modulo',
    '<operator>.minus',
    '<operator>.plus',
    '<operator>.not',
    '<operator>.arithmeticShiftRight',
    '<operator>.arithmeticShiftLeft',
    '<operator>.lessEqualsThan',
    '<operator>.greaterEqualsThan',
    '<operator>.lessThan',
    '<operator>.greaterThan',
    '<operator>.indirection',
    '<operator>.memberAccess',
    '<operator>.sizeOf',
    '<operator>.shiftLeft',
    '<operator>.shiftRight']

assigntype = {
    '<operator>.assignmentPlus': '<operator>.plus',
    '<operator>.assignmentMultiplication': '<operator>.multiplication',
    '<operator>.assignmentDivision':'<operator>.division',
    '<operator>.assignmentMinus':'<operator>.minus',
    '<operators>.assignmentAnd':'<operator>.and',
    '<operator>.assignmentAnd':'<operator>.and',
    '<operators>.assignmentOr':'<operator>.or',
    '<operators>.assignmentXor':'<operator>.or',
    '<operators>.assignmentModulo':'<operator>.modulo',
    '<operators>.assignmentExponentiation':'<operator>.exponentiation',
    '<operators>.assignmentArithmeticShiftRight':'<operator>.arithmeticShiftRight',
    '<operators>.assignmentShiftLeft': '<operators>.LogicalShifRight',
    '<operator>.postIncrement':'<operator>.plus',
    '<operator>.preIncrement':'<operator>.plus',
    '<operator>.postDecrement':'<operator>.minus',
    '<operator>.preDecrement':'<operator>.minus'}

code2type = { 
    '<operator>.plus':                          1,
    '<operator>.addition':                      1,
    '<operator>.subtraction':                   2,
    '<operator>.multiplication':                3,
    '<operator>.division':                      4,
    '<operator>.modulo':                        5,
    '<operator>.or':                            6,
    '<operator>.and':                           7,
    '<operator>.not':                           8,
    '<operator>.shiftRight':                    9,
    '<operators>.LogicalShifRight':             9,
    '<operator>.arithmeticShiftRight':          9,
    '<operator>.arithmeticShiftLeft':           9,
    '<operator>.shiftLeft':                     9,
    '<operator>.equals':                        10, #
    '<operator>.notEquals':                     11, #
    '<operator>.lessEqualsThan':                12,
    '<operator>.lessThan':                      12,
    '<operator>.greaterEqualsThan':             13,
    '<operator>.greaterThan':                   13,
    '<operator>.logicalNot':                    14,
    '<operator>.logicalOr':                     15,
    '<operator>.logicalAnd':                    16,
    '<operator>.sizeOf':                        17,
    # --- drop ---
    '<operator>.addressOf':                     18,
    '<operator>.minus':                         19, 
    '<operator>.cast':                          20,
    '<operator>.indirectMemberAccess':          21,          
    '<operator>.computedMemberAccess':          21,
    '<operator>.indirection':                   21,
    '<operator>.memberAccess':                  21,
    '<operator>.assignment':                    22,
}


def makeBlock(g):
    nlist = list(g.nodes())
    for n in nlist:
        if not ('Call@' in n or 'Return@' in n):
            pre = list(g.predecessors(n))
            suc = list(g.successors(n))
            
            if len(pre)>0 and len(suc) >0:
                for p in pre:
                    for s in suc:
                        t = list(set(g.edges()[(p, n)]['type'] + g.edges()[(n, s)]['type']))
                        if len(t) > 1:
                            print('d')
                        g.add_edge(p,s, type = t)
            g.remove_node(n)
    return g


def normGraph(g, gtype):
    for n in list(g.nodes()):
        try:
            pdict = g.nodes()[n]['property']
        except:
            g.nodes()[n]['line'] = []
            g.nodes()[n]['type'] = []
            continue
        g.nodes()[n]['line'] = pdict['LINE_NUMBER']
        if 'Return@' in n:
            g.nodes()[n]['type'] = 'return'
            g.nodes()[n]['stm'] = 'return'
            g.nodes()[n].pop('property')
            continue
        if 'Unknown@' in n:
            g.nodes()[n]['type'] = 'unknown'
            g.nodes()[n]['stm'] = 'unknown'
            g.nodes()[n].pop('property')
            continue
        stm = pdict['NAME']
        if not stm in codetype:
            g.nodes()[n]['type'] = 'api'
            fname = stm.lower().strip()
            if '()' in fname:
                fname = fname.replace('()','')
            if '->' in fname:
                fname = fname.split('->')[-1]
            if '.' in fname:
                fname = fname.split('.')[-1]
            if ')' in fname:
                fname = fname.replace(')','')
            if '(' in fname:
                fname = fname.split('(')[0]
            if '~' in fname:
                fname = fname.split('~')[1]
            if ',' in fname:
                fname = fname.split(',')[0].strip()
            if '[' in fname:
                fname = fname.split('[')[0].strip()
            g.nodes()[n]['stm'] = fname
        else:
            g.nodes()[n]['type'] = 'opr'
            g.nodes()[n]['stm'] = stm
        g.nodes()[n].pop('property')
    nlist = list(g.nodes())
    for n in nlist:
        if 'MethodReturn@' in n:
            g.add_node('MethodReturn')
            g.nodes()['MethodReturn']['line'] = '-1'
            g.nodes()['MethodReturn']['type'] = 'methodreturn'
            g.nodes()['MethodReturn']['stm'] = 'methodreturn'
            pre = list(g.predecessors(n))
            for p in pre:
                g.add_edge(p,'MethodReturn', type = g.edges()[(p, n)]['type'])
            g.remove_node(n)
            continue
        if g.nodes()[n]['stm'] == '<operator>.conditionalExpression':
            g.nodes()[n]['stm'] = '<operator>.assignment'
            continue
        if g.nodes()[n]['stm'] == '<operator>.cast':
            pre = list(g.predecessors(n))
            suc = list(g.successors(n))
            for p in pre:
                for s in suc:
                    g.add_edge(p,s, type = g.edges()[(n, s)]['type'])
            g.remove_node(n)
            continue
        if g.nodes()[n]['stm'] in assigntype:
            stm1 = '<operator>.assignment'
            stm2 = assigntype[g.nodes()[n]['stm']]
            l = g.nodes()[n]['line']
            t = 'opr'
            g.add_node(n+'_p', line = l,type = t,stm = stm1)
            g.add_node(n+'_s', line = l,type = t,stm = stm2)
            if gtype == 'cfg':
                g.add_edge(n+'_p',n+'_s', type = ['cfg'])
            else:
                g.add_edge(n+'_p',n+'_s', type = ['ddg'])
            pre = list(g.predecessors(n))
            suc = list(g.successors(n))
            for p in pre:
                g.add_edge(p,n+'_p', type = g.edges()[(p, n)]['type'])
            for s in suc:
                g.add_edge(n+'_s',s, type = g.edges()[(n, s)]['type'])
            g.remove_node(n)
    nlist = list(g.nodes())
    for n in nlist:
        if g.nodes()[n]['stm'] == '<operator>.assignment':
            pre = list(g.predecessors(n))
            suc = list(g.successors(n))
            for p in pre:
                for s in suc:
                    t = list(set(g.edges()[(p, n)]['type']+g.edges()[(n, s)]['type']))

                    g.add_edge(p,s, type=t)
            g.remove_node(n)
    return g


def getgraph(funcname, funccfg, funcpdg):
    cfg = nx.DiGraph()
    pdg = nx.DiGraph()
    cfg.name = funcname
    pdg.name = funcname
    for c in funccfg:
        prop = c['properties']
        propdict = dict()
        for pp in prop:
            propdict[pp['key']] = pp['value']
        cfg.add_node(c['id'].split('.')[-1], property=propdict)
        pdg.add_node(c['id'].split('.')[-1], property=propdict)
        for e in c['edges']:
            cfg.add_edge(e['out'].split('.')[-1], e['in'].split('.')[-1], type=['cfg'])
    for c in funcpdg:
        for e in c['edges']:
            if not ('Return' in e['out'] or 'Return' in e['in']):
                if (e['out'].split('.')[-1], e['in'].split('.')[-1]) in pdg.edges():
                    if 'ReachingDef' in e['id']: 
                        t = pdg.edges()[e['out'].split('.')[-1], e['in'].split('.')[-1]]['type']
                        pdg.add_edge(e['out'].split('.')[-1], e['in'].split('.')[-1], type=list(set(t + ['ddg'])))
                    elif 'Cdg' in e['id']: 
                        t = pdg.edges()[e['out'].split('.')[-1], e['in'].split('.')[-1]]['type']
                        pdg.add_edge(e['out'].split('.')[-1], e['in'].split('.')[-1], type=list(set(t + ['cdg'])))
                else:
                    if 'ReachingDef' in e['id']: 
                        pdg.add_edge(e['out'].split('.')[-1], e['in'].split('.')[-1], type=['ddg'])
                    elif 'Cdg' in e['id']: 
                        pdg.add_edge(e['out'].split('.')[-1], e['in'].split('.')[-1], type=['cdg'])
    nlist = list(cfg.nodes())
    for n in nlist:
        if 'MethodReturn' in n:
            try:
                pdg.remove_node(n)
            except:
                pass
    return cfg, pdg


def forward(bbg, n, hopsize, edge_type):
    count = 0
    sucedge  = []
    while count < hopsize :
        if len(n) >  100:
            raise ValueError
        count += 1
        suc = []
        for ni in n:
            sucnode = list(bbg.successors(ni))
            # print('start from:', ni )
            # print('to: ', list(bbg.successors(ni)))
            sucnode = [s for s in sucnode if edge_type in bbg.edges()[(ni, s)]['type'] ]
            suc += sucnode
            sucedge += [(ni, s) for s in sucnode]
        newnode = []
        for s in suc:
           if not s in n:
                newnode.append(s)
        if len(newnode) == 0:
            break
        n += newnode
    return n, sucedge


def backward(bbg, n, hopsize, edge_type):
    count = 0
    preedge  = []
    while count < hopsize:
        if len(n) >  100:
            raise ValueError
        count += 1
        pre = []
        for ni in n:
            prenode = list(bbg.predecessors(ni))
            # print('start from:', ni )
            # print('to: ', list(bbg.predecessors(ni)))
            prenode = [p for p in prenode if edge_type in bbg.edges()[(p, ni)]['type'] ]
            pre += prenode
            preedge += [(p, ni) for p in prenode]
        newnode = []
        for p in pre:
            if not p in n:
                newnode.append(p)
        if len(newnode) == 0:
            break
        n += newnode
    return n, preedge

def g_sample(tgraph, n, hopsize, gtype):
    if gtype == 'cfg':
        try:
            nsus, edgesus = forward(tgraph, [n], hopsize, 'cfg')
            npre, edgepre = backward(tgraph, [n], hopsize, 'cfg')
        except ValueError:
            return None
        g = nx.Graph()
        g.add_node(n, line = tgraph.nodes()[n]['line'], type = tgraph.nodes()[n]['type'], stm = tgraph.nodes()[n]['stm'])
        for ns in nsus[1:]:
            g.add_node(ns, line = tgraph.nodes()[ns]['line'], type = tgraph.nodes()[ns]['type'], stm = tgraph.nodes()[ns]['stm'])
        for es in edgesus:
            g.add_edge(es[0],es[1])
        for np in npre[1:]:
            g.add_node(np, line = tgraph.nodes()[np]['line'], type = tgraph.nodes()[np]['type'], stm = tgraph.nodes()[np]['stm'])
        for ep in edgepre:
            g.add_edge(ep[0], ep[1])
        return g
    else:
        try:
            # nsus_cdg, edgesus_cdg = forward(tgraph, [n], hopsize, 'cdg')
            # npre_cdg, edgepre_cdg = backward(tgraph, [n], hopsize, 'cdg')

            nsus_ddg, edgesus_ddg = forward(tgraph, [n], hopsize, 'ddg')
            npre_ddg, edgepre_ddg = backward(tgraph, [n], hopsize, 'ddg')
        except ValueError:
            return None, None
        # cdg = nx.Graph()
        # cdg.add_node(n, line = tgraph.nodes()[n]['line'], type = tgraph.nodes()[n]['type'], stm = tgraph.nodes()[n]['stm'])
        # for ns in nsus_cdg[1:]:
        #     cdg.add_node(ns, line = tgraph.nodes()[ns]['line'], type = tgraph.nodes()[ns]['type'], stm = tgraph.nodes()[ns]['stm'])
        # for es in edgesus_cdg:
        #     cdg.add_edge(es[0],es[1])

        # for np in npre_cdg[1:]:
        #     cdg.add_node(np, line = tgraph.nodes()[np]['line'], type = tgraph.nodes()[np]['type'], stm = tgraph.nodes()[np]['stm'])
        # for ep in edgepre_cdg:
        #     cdg.add_edge(ep[0], ep[1])

        ddg = nx.Graph()
        ddg.add_node(n, line = tgraph.nodes()[n]['line'], type = tgraph.nodes()[n]['type'], stm = tgraph.nodes()[n]['stm'])


        for ns in nsus_ddg[1:]:
            ddg.add_node(ns, line = tgraph.nodes()[ns]['line'], type = tgraph.nodes()[ns]['type'], stm = tgraph.nodes()[ns]['stm'])
        for es in edgesus_ddg:
            ddg.add_edge(es[0],es[1])

        for np in npre_ddg[1:]:
            ddg.add_node(np, line = tgraph.nodes()[np]['line'], type = tgraph.nodes()[np]['type'], stm = tgraph.nodes()[np]['stm'])
        for ep in edgepre_ddg:
            ddg.add_edge(ep[0], ep[1])

        return None, ddg


# def gmerge(cent, subc, subp):
#     g = nx.Graph()
#     g.add_node('cent_'+cent, line = subc.nodes()[cent]['line'], type = subc.nodes()[cent]['type'], stm = subc.nodes()[cent]['stm'])
    
#     for cnode in subc.nodes():
#         if not cnode == cent:
#             g.add_node('c_'+cnode, line = subc.nodes()[cnode]['line'], type = subc.nodes()[cnode]['type'], stm = subc.nodes()[cnode]['stm'])
#     for pnode in subp.nodes():
#         if not pnode == cent:
#             g.add_node('p_'+pnode, line = subp.nodes()[pnode]['line'], type = subp.nodes()[pnode]['type'], stm = subp.nodes()[pnode]['stm'])
    
#     for e in subc.edges():
#         if not e[0] == cent and not e[1] == cent:
#             g.add_edge('c_'+e[0], 'c_'+e[1])
#         elif e[0] == cent and e[1] == cent:
#             continue
#         elif e[0] == cent:
#             g.add_edge('cent_'+cent, 'c_'+e[1])
#         elif e[1] == cent:
#             g.add_edge('c_'+e[0], 'cent_'+cent)
#     for e in subp.edges():
#         if not e[0] == cent and not e[1] == cent:
#             g.add_edge('p_'+e[0], 'p_'+e[1])
#         elif e[0] == cent and e[1] == cent:
#             continue
#         elif e[0] == cent:
#             g.add_edge('cent_'+cent, 'p_'+e[1])
#         elif e[1] == cent:
#             g.add_edge('p_'+e[0], 'cent_'+cent)
#     return g


def gmerge(cent, subc,  subcdg, subddg):
    g = nx.Graph()
    g.add_node('cent_'+cent, line = subc.nodes()[cent]['line'], type = subc.nodes()[cent]['type'], stm = subc.nodes()[cent]['stm'])

    for cnode in subc.nodes():
        if not cnode == cent:
            g.add_node(cnode, line = subc.nodes()[cnode]['line'], type = subc.nodes()[cnode]['type'], stm = subc.nodes()[cnode]['stm'])

    # for pnode in subcdg.nodes():
    #     if not pnode == cent:
    #         g.add_node(pnode, line = subcdg.nodes()[pnode]['line'], type = subcdg.nodes()[pnode]['type'], stm = subcdg.nodes()[pnode]['stm'])
    for pnode in subddg.nodes():
        if not pnode == cent:
            g.add_node(pnode, line = subddg.nodes()[pnode]['line'], type = subddg.nodes()[pnode]['type'], stm = subddg.nodes()[pnode]['stm'])


    for e in subc.edges():
        if not e[0] == cent and not e[1] == cent:
            g.add_edge(e[0], e[1])
        elif e[0] == cent and e[1] == cent:
            continue
        elif e[0] == cent:
            g.add_edge('cent_'+cent, e[1])
        elif e[1] == cent:
            g.add_edge(e[0], 'cent_'+cent)
    # for e in subcdg.edges():
    #     if not e[0] == cent and not e[1] == cent:
    #         g.add_edge(e[0], e[1])
    #     elif e[0] == cent and e[1] == cent:
    #         continue
    #     elif e[0] == cent:
    #         g.add_edge('cent_'+cent, e[1])
    #     elif e[1] == cent:
    #         g.add_edge(e[0], 'cent_'+cent)

    for e in subddg.edges():
        if not e[0] == cent and not e[1] == cent:
            g.add_edge(e[0], e[1])
        elif e[0] == cent and e[1] == cent:
            continue
        elif e[0] == cent:
            g.add_edge('cent_'+cent, e[1])
        elif e[1] == cent:
            g.add_edge(e[0], 'cent_'+cent)
            
    return g


def gtostr(g, n):
    gnode = ['cent_'+n] + [successor for successors in dict(nx.bfs_successors(g, 'cent_'+n)).values() for successor in successors]
    adj = []
    types = [g.nodes()[gn]['type'] for gn in g.nodes()]
    gedge = g.edges()
    for idxi, i in enumerate(gnode):
        for idxj, j in enumerate(gnode):
            if (i,j) in gedge:
                adj.append(str([idxi,idxj]))
                adj.append(str([idxj,idxi]))
    return [len(types), str([types, sorted(list(set(adj)))])]


def g2feats(g, input_dim, wvec_dim, ldict):
    feat = np.zeros(input_dim)
    gnode = list(g.nodes())
    for n in gnode:
        callstm = g.nodes()[n]["stm"]
        calltype = g.nodes()[n]["type"]
        if calltype == 'api':
            try:
                label = ldict[callstm]
            except Exception:
                label = input_dim - 1
            gvec = label
        elif calltype == 'opr':
            label = code2type[callstm]
            gvec = wvec_dim + label
        elif calltype == 'return': 
            gvec = input_dim - 2
        elif calltype == 'block':
            gvec = input_dim - 1
        feat[gvec] += 1
        g.nodes()[n]['label'] = gvec
    return feat, g


def seedg2feat(gnode, gedges, tgraph, ldict, input_dim, wvec_dim, iline):
    sg = nx.Graph()
    feat = np.zeros(input_dim)
    for idxn, n in enumerate(gnode):
        gvec = wvec_dim
        try:
            callstm = tgraph.nodes()[n]["stm"]
            calltype = tgraph.nodes()[n]["type"]
            if calltype == 'api':
                label = ldict[callstm]
                gvec = label - 1
            elif calltype == 'opr':
                label = code2type[callstm]
                gvec = wvec_dim + label
            else: 
                gvec = input_dim-1
        except KeyError:
            pass
        sg.add_node('n'+str(idxn), label = gvec)
        
    for e in gedges:
        if e[0] in gnode and e[1] in gnode:
            sg.add_edge('n'+str(gnode.index(e[0])), 'n'+str(gnode.index(e[1])))
    for n in list(sg.nodes()):
        f = sg.nodes()[n]['label']
        feat[f] += 1
    return sg, feat


def seed2g(tgraph, ilines, centapi, hopsize, gtype):
    centnode = None
    for n in tgraph.nodes():
        try:
            if int(tgraph.nodes()[n]['line']) == ilines[0] and tgraph.nodes()[n]['stm'] == centapi:
                centnode = n
        except Exception:
            pass
    if centnode == None:
        return None, None, None

    if gtype == 'cfg':
        nsus, edgesus = forward(tgraph, [centnode], hopsize, 'cfg')
        npre, edgepre = backward(tgraph, [centnode], hopsize, 'cfg')
        g = nx.Graph()
        g.add_node(centnode, line = tgraph.nodes()[centnode]['line'], type = tgraph.nodes()[centnode]['type'], stm = tgraph.nodes()[centnode]['stm'])
        
        for ns in nsus[1:]:
            if int(tgraph.nodes()[ns]['line']) in ilines:
                g.add_node(ns, line = tgraph.nodes()[ns]['line'], type = tgraph.nodes()[ns]['type'], stm = tgraph.nodes()[ns]['stm'])
        
        for es in edgesus:
            if int(tgraph.nodes()[es[0]]['line']) in ilines and int(tgraph.nodes()[es[1]]['line']) in ilines:
                g.add_edge(es[0],es[1])

        for np in npre[1:]:
            if int(tgraph.nodes()[np]['line']) in ilines:
                g.add_node(np, line = tgraph.nodes()[np]['line'], type = tgraph.nodes()[np]['type'], stm = tgraph.nodes()[np]['stm'])
        for ep in edgepre:
            if int(tgraph.nodes()[ep[0]]['line']) in ilines and int(tgraph.nodes()[ep[1]]['line']) in ilines:
                g.add_edge(ep[0], ep[1])
        return g, centnode, None
        
    else:
        nsus_cdg, edgesus_cdg = forward(tgraph, [centnode], hopsize, 'cdg')
        npre_cdg, edgepre_cdg = backward(tgraph, [centnode], hopsize, 'cdg')

        nsus_ddg, edgesus_ddg = forward(tgraph, [centnode], hopsize, 'ddg')
        npre_ddg, edgepre_ddg = backward(tgraph, [centnode], hopsize, 'ddg')

        cdg = nx.Graph()
        cdg.add_node(centnode, line = tgraph.nodes()[centnode]['line'], type = tgraph.nodes()[centnode]['type'], stm = tgraph.nodes()[centnode]['stm'])
        
        for ns in nsus_cdg[1:]:
            if int(tgraph.nodes()[ns]['line']) in ilines:
                cdg.add_node(ns, line = tgraph.nodes()[ns]['line'], type = tgraph.nodes()[ns]['type'], stm = tgraph.nodes()[ns]['stm'])
        for es in edgesus_cdg:
            if int(tgraph.nodes()[es[0]]['line']) in ilines and int(tgraph.nodes()[es[1]]['line']) in ilines:
                cdg.add_edge(es[0],es[1])

        for np in npre_cdg[1:]:
            if int(tgraph.nodes()[np]['line']) in ilines:
                cdg.add_node(np, line = tgraph.nodes()[np]['line'], type = tgraph.nodes()[np]['type'], stm = tgraph.nodes()[np]['stm'])
        for ep in edgepre_cdg:
            if int(tgraph.nodes()[ep[0]]['line']) in ilines and int(tgraph.nodes()[ep[1]]['line']) in ilines:
                cdg.add_edge(ep[0], ep[1])
        
        ddg = nx.Graph()
        ddg.add_node(centnode, line = tgraph.nodes()[centnode]['line'], type = tgraph.nodes()[centnode]['type'], stm = tgraph.nodes()[centnode]['stm'])
        
        for ns in nsus_ddg[1:]:
            if int(tgraph.nodes()[ns]['line']) in ilines:
                ddg.add_node(ns, line = tgraph.nodes()[ns]['line'], type = tgraph.nodes()[ns]['type'], stm = tgraph.nodes()[ns]['stm'])
        for es in edgesus_ddg:
            if int(tgraph.nodes()[es[0]]['line']) in ilines and int(tgraph.nodes()[es[1]]['line']) in ilines:
                ddg.add_edge(es[0],es[1])

        for np in npre_ddg[1:]:
            if int(tgraph.nodes()[np]['line']) in ilines:
                ddg.add_node(np, line = tgraph.nodes()[np]['line'], type = tgraph.nodes()[np]['type'], stm = tgraph.nodes()[np]['stm'])
        for ep in edgepre_ddg:
            if int(tgraph.nodes()[ep[0]]['line']) in ilines and int(tgraph.nodes()[ep[1]]['line']) in ilines:
                ddg.add_edge(ep[0], ep[1])

        return cdg, ddg, centnode