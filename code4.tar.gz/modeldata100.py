
import random as rd
 
import networkx as nx
 
import utils

rd.seed(2)
inputdim = 100
wvec_dim = 76
 

class DiskDataSource:
    def __init__(self, dataset):
        self.dataset = dataset

    def gen_data_loaders(self, batch_num, batch_size):
        loaders = [batch_size]* batch_num
        return loaders

    def gen_batch(self, batch_i, nodenum):
        batch_size = batch_i
        trainsets = self.dataset[nodenum]
        trainset = trainsets
        trainkey = sorted(list(self.dataset.keys()))
        # trainidx = trainkey.index(nodenum)
        anclist, poslists, neglists = [], [], []
        ancnum = rd.choice(list(range(4, min(10, nodenum - 4))))
        idxlist = list(range(ancnum + 1, nodenum))
        idxlist = sorted(rd.sample(idxlist, 4)+[nodenum])
        for i in range(batch_size):
            poslist = []
            
            sample = rd.choice(trainset)
            types = sample[1]
            edge = [eval(e) for e in sample[2]]
            

            ns = [rd.choice(list(range(wvec_dim))) 
                        if types[nidx] == 'api' 
                        else rd.choice(list(range(wvec_dim,inputdim)))
                        for nidx in range(0,nodenum)]
            
            alist = list(range(0,ancnum))
            e = [i for i in edge if i[0] < ancnum and i[1] < ancnum]
            ga = nx.Graph()
            for ni in alist:
                ga.add_node('n_'+str(ni), label = ns[ni])
            for ei in e:
                ga.add_edge('n_'+str(ei[0]), 'n_'+str(ei[1]))
            anclist.append(ga)

            for n in idxlist:
                nlist = list(range(0,n))
                e = [i for i in edge if i[0] < n and i[1] < n]
                gi = nx.Graph()
                for ni in nlist:
                    gi.add_node('n_'+str(ni), label = ns[ni])
                for ei in e:
                    gi.add_edge('n_'+str(ei[0]), 'n_'+str(ei[1]))
                poslist.append(gi)

            ancapi = [ni for ni in ns[:ancnum] if ni < wvec_dim]
            ancopr = [ni for ni in ns[:ancnum] if ni >= wvec_dim]

            neglist = []

            sample = rd.choice(trainset)
            types = sample[1]
            edge = [eval(e) for e in sample[2]]
            
            napi = [rd.choice(list(range(wvec_dim))) for nidx in range(0,len(types)) if types[nidx] == 'api' ]
            nopr = [rd.choice(list(range(wvec_dim, inputdim))) for nidx in range(0,len(types)) if types[nidx] is not 'api' ]

            napi = ancapi + napi[len(ancapi):]
            rd.shuffle(napi)
            nopr = ancopr + nopr[len(ancopr):]
            rd.shuffle(nopr)

            napicount = 0
            noprcount = 0
            nns = []
            for idx in range(len(types)):
                t = types[idx]
                if t == 'api':
                    nns.append(napi[napicount])
                    napicount += 1
                else:
                    nns.append(nopr[noprcount])
                    noprcount += 1

            for n in idxlist:
                nlist = list(range(0,n))
                e = [i for i in edge if i[0] < n and i[1] < n]
                gi = nx.Graph()
                for ni in nlist:
                    gi.add_node('n_'+str(ni), label = nns[ni])
                for ei in e:
                    gi.add_edge('n_'+str(ei[0]), 'n_'+str(ei[1]))
                neglist.append(gi)

            poslists.append(poslist)
            neglists.append(neglist)

        pos = []
        n = []
        anc = utils.batch_nx_graphs(anclist)
        for i in range(5):
            plist = [poslists[j][i] for j in range(batch_i)]
            nlist = [neglists[j][i] for j in range(batch_i)]
            pos.append(utils.batch_nx_graphs(plist)) 
            n.append(utils.batch_nx_graphs(nlist)) 

        return anc, pos, n, None, 5


    def gen_retrieval_loaders(self, size, batch_size):
        loaders = [list(range(i, min(i+batch_size, size))) for i in list(range(0,size, batch_size))]
        return loaders

    def gen_retrieval_batch(self, batch_i):
        graphs = self.dataset
        g = [] 
        for i in  batch_i :
            sample = graphs[i]
            g.append(sample)
        g = utils.batch_nx_graphs(g)
        return g

    def gen_clf_batch(self, batch_i, train):
        batch_size = batch_i
        poslist, neg1, neg2 = [], [], []
        for i in range(batch_size):
            while(1):
                nodenum = rd.choice(list(self.dataset.keys()))
                if nodenum >=5:
                    break
            sample = rd.choice(self.dataset[nodenum])
            edge = [eval(e) for e in sample[1]]
            plist = []
            ns = [rd.choice(list(range(inputdim))) for _ in list(range(0,nodenum))]
            for n in range(nodenum-2, nodenum+1):
                nlist = list(range(0,n))
                e = [i for i in edge if i[0] < n and i[1] < n]
                gi = nx.Graph()
                for ni in nlist:
                    gi.add_node('n'+str(ni), label = ns[ni])
                for ei in e:
                    gi.add_edge('n'+str(ei[0]), 'n'+str(ei[1]))
                plist.append(gi)

            n1ns = [rd.choice(list(range(inputdim))) for _ in list(range(0,nodenum))]
            nlist = list(range(0,nodenum))
            gn1 = nx.Graph()
            for ni in nlist:
                gn1.add_node('n'+str(ni), label = ns[ni] if ni < nodenum-1 else n1ns[ni])
            for ei in edge:
                gn1.add_edge('n'+str(ei[0]), 'n'+str(ei[1]))
            neg1.append(gn1)

            # for n in range(nodenum-3, nodenum+1):
            n2 = rd.choice(self.dataset[rd.choice(list(self.dataset.keys()))])
            nlist = list(range(0,n2[0]))
            n2ns = [rd.choice(list(range(inputdim))) for _ in nlist]
            gn2 = n2[2]
            for ni in nlist:
                gn2.add_node('n'+str(ni), label = n2ns[ni])
            neg2.append(gn2)
            poslist.append(plist)
            
        pos = []
        for i in range(3):
            plist = [poslist[j][i] for j in range(batch_i)]
            pos.append(utils.batch_nx_graphs(plist))
        neg1 = utils.batch_nx_graphs(neg1)
        neg2 = utils.batch_nx_graphs(neg2)
        return pos[2], pos[1], pos[0], neg1, neg2
    

 