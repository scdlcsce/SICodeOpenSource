import networkx as nx
import pickle as pkl
rootpath = '/home/sise/sda/gyj/NM/411data/725kernel/seed/'
graphpath = '0__lpass_platform_pcmops_open.pkl'
g = pkl.load(open(rootpath+ graphpath, 'rb'))
inodes = ['Call@54','Call@5d','Call@80','Call@8b','Return@60','Return@90']
subg = g.subgraph(inodes)
seedg = nx.DiGraph()
for ni in subg.nodes():
    seedg.add_node(ni, stm = subg.nodes()[ni]['stm'], type = subg.nodes()[ni]['type'], line = subg.nodes()[ni]['line'])
seedg.add_edges_from(subg.edges())

pkl.dump(seedg, open(rootpath+'seed_vul3_'+graphpath, 'wb'))