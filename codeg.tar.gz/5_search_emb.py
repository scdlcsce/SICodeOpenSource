import  torch
import argparse
from config import parse_encoder
import models
from gutils import getgraph, makeBlock, normGraph, seed2g, gmerge, g2feats
import utils
from datetime import datetime
from tqdm import tqdm
import json
from tqdm import tqdm
import pickle as pkl
import numpy as np

input_dim = 50
wvec_dim = 27
from modeldata50 import DiskDataSource

with open('/home/sise/sda/gyj/NM/openssl_increase/data/funccobert_cluster_27.txt', 'r') as fid:
    ldict = eval(fid.read())
    
[namelist1, subgraphlist, featslist] = pkl.load(open('/home/sise/sda/gyj/NM/openssl_increase/data/subgraph_50.pkl', 'rb'))
[namelist2, emb_T, feat_T] = pkl.load(open('/home/sise/sda/gyj/NM/openssl_increase/subgraph_matching/2.22result/embedding4', 'rb'))

model_path = '/home/sise/sda/gyj/NM/openssl_increase/ckpt_50/params_028_75n.pt'


def build_model(args):
    model = models.OrderEmbedder(args)
    model.to(utils.get_device())
    return model


if __name__ == "__main__":

    seedfile = 's_server'
    seedfunc = 'www_body'
    vinfo = eval("[[2991,2992],'BIO_new']")
    # seedfile = 'asn1_parse'
    # seedfunc = 'asn1_print_info'
    # vinfo = eval("[[45],'BIO_new']")
    # seedfile = 'bio_ndef'
    # seedfunc = 'ndef_prefix'
    # vinfo = eval("[[117,116],'OPENSSL_malloc']")

    vinfo = (vinfo[0], vinfo[1].lower())
    hopsize = 4


    filedir='/mnt/sdc/gyj/bakNM/NMgraph-one/data/openssl/code/vul/'+seedfile
    # filedir='/home/sise/sda/gyj/bakNM/NMgraph-one/data/openssl/code/vul/'+seedfile
    with open(filedir+'_cfg.json','r') as fp:
        jdata = json.load(fp)
    with open(filedir+'_pdg.json','r') as fp:
        pdata = json.load(fp)
    funccfg = None
    funcpdg = None
    for f in jdata['functions']:
        if f['function'] == seedfunc:
            funccfg = f['CFG']
    for f in pdata['functions']:
        if f['function'] == seedfunc:
            funcpdg = f['PDG']
    if funccfg == None or funcpdg == None:
        print("Function cannot find.")
        exit()
    
    cfg1, pdg1 = getgraph(seedfunc, funccfg, funcpdg)
    cfg2 = makeBlock(cfg1)
    pdg2 = makeBlock(pdg1)
    cfg = normGraph(cfg2, 'cfg')
    pdg = normGraph(pdg2, 'pdg')

    cdg_seed, ddg_seed, pdg_cent = seed2g(pdg, vinfo[0], vinfo[1], hopsize, 'pdg')
    cfg_seed, cfg_cent, _ = seed2g(cfg, vinfo[0], vinfo[1], hopsize, 'cfg')

    assert pdg_cent == cfg_cent
    assert not pdg_cent == None

    g_seed = gmerge(pdg_cent, cfg_seed, cdg_seed, ddg_seed)
    
    feat, g = g2feats(g_seed, ldict, input_dim, wvec_dim)



    assert namelist1 == namelist2
    namelist = namelist1

    featslist =np.asarray(featslist)
    idxs = np.where(np.min(featslist - feat,axis = 1)>=0)[0]
    s_namelist = [namelist[i] for i in idxs.tolist()]
    # s_func = list(set([s.split('_Call@')[0] for s in s_namelist]))

    # with open('/home/sise/sda/gyj/NM/openssl_increase/subgraph_matching/logft','w')as fp:
    #     fp.write(str(s_namelist) + str(len(s_func)))

    parser = (argparse.ArgumentParser(description='Order embedding arguments'))
    utils.parse_optimizer(parser)
    parse_encoder(parser)
    args = parser.parse_args()

    model = models.OrderEmbedder(args)
    model.to(utils.get_device())
    model.load_state_dict(torch.load(model_path))
    model.eval()

    Sdata_source = DiskDataSource([g_seed])
    loaders = Sdata_source.gen_retrieval_loaders(1, 1)
    for batch_i in tqdm(loaders):
        v = Sdata_source.gen_retrieval_batch(batch_i)
        with torch.no_grad():
            emb_v = model.emb_model(v)
            
    s = emb_v.expand(emb_T.shape)
    raw_pred = model.predict(emb_T.to(utils.get_device()), s)

    pred = [0 if raw_pred[idx]>0.8 else 1 for idx in range(int(raw_pred.shape[0]))]
    # p_namelist = [namelist[idxp] for idxp, p in enumerate(pred) if p ==1 ]
    # p_func = list(set([p.split('_Call@')[0] for p in p_namelist]))

    # with open('/home/sise/sda/gyj/NM/openssl_increase/subgraph_matching/logemb','w')as fp:
    #     fp.write(str(p_namelist)+ str(len(p_func)))
    
    # p_namelist = [namelist[idxp] for idxp, p in enumerate(pred) if p ==1 ]
    # p_namelist = [p for p in s_namelist if p in p_namelist]

    p_dict = {namelist[idxp]:raw_pred[idxp].item() for idxp, p in enumerate(pred) if (p ==1 and namelist[idxp] in s_namelist) }
    p_dict = sorted(p_dict.items(), key=lambda d: d[1], reverse=False)

    p_func = []
    for p in p_dict:
        f = p[0].split('_Call@')[0]
        if not f in p_func:
            p_func.append(f)

    p_dict = [p[0] for p in p_dict]

    with open('/home/sise/sda/gyj/NM/openssl_increase/subgraph_matching/2.22result/log43','w')as fp:
        fp.write(str(p_dict)+'\n\n\n'+ str(p_func))
