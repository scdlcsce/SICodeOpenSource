import os
from tqdm import tqdm
jsondir = '/home/sise/sda/gyj/NM/graphdomain_openssl/data/wireshark_code/codebase_b/'
listdir = '/home/sise/sda/gyj/NM/graphdomain_openssl/data/wireshark_code/list.txt'
astdir = '/home/sise/sda/gyj/NM/graphdomain_openssl/data/wireshark_code/ast.txt'
alldir = '/home/sise/sda/gyj/NM/graphdomain_openssl/data/wireshark_code/all.txt'
# c = 'find {} -name "*.c" > {}'.format(jsondir, listdir)
# os.system(c)
# c = 'find {} -name "*.ast" > {}'.format(jsondir, astdir)
# os.system(c)

# with open(listdir, 'r')as fp:
#     clist = fp.readlines()
# with open(astdir, 'r') as fp:
#     astlist = fp.readlines()
# crestlist = [c for c in clist if not c[:-1]+'.ast\n' in astlist]

# c = 'find {} -name "*.*" > {}'.format(jsondir, alldir)
# os.system(c)
# with open(alldir, 'r')as fp:
#     clist = fp.readlines()
# a = [c for c in clist if not c in crestlist]
# for aa in tqdm(a):
#     os.system("rm {}".format(aa[:-1]))

c = 'find {} -name "*.ast" > {}'.format(jsondir, astdir)
os.system(c)
with open(astdir, 'r')as fp:
    astlist = fp.readlines()
for aa in tqdm(astlist):
    c = 'mv '+ aa.strip() + ' ' + aa.strip().replace('codebase_b', 'codebase_a')
    os.system(c)
    c = 'rm '+ aa[:-5]
    os.system(c)