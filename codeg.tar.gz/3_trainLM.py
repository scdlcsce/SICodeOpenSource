from gensim.models import word2vec
from gensim.models import FastText
import time

if __name__ == "__main__":
    print(time.time())
    with open('/home/sise/sda/gyj/NM/graphdomain_openssl/timetest/vlc-vocab.txt')as fp:
        vocab = fp.readlines()
    sentences = word2vec.Text8Corpus('/home/sise/sda/gyj/NM/graphdomain_openssl/timetest/vlc-corpus.txt')
    model = FastText(sentences, size=64, window=3, min_count=1)
    emb = []
    for i in vocab:
        i = i.strip()
        try:
            e = model[i].tolist()
        except Exception:
            e = None
        emb.append(e)
    
    with open('/home/sise/sda/gyj/NM/graphdomain_openssl/timetest/vlc-ft.txt','w') as fp:
            fp.write(str(emb))
    # sentences = word2vec.Text8Corpus('/home/sise/sda/gyj/NM/graphdomain_openssl/data/wireshark-corpus.txt')
    # model=word2vec.Word2Vec(sentences,sg=1, size=64,window=5,min_count=1,sample=0.001,hs=0,workers=4)
    # emb = []
    # for i in vocab:
    #     i = i.strip()
    #     try:
    #         e = model[i].tolist()
    #     except Exception:
    #         e = None
    #     emb.append(e)
    
    # with open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/wireshark-wv.txt','w') as fp:
    #         fp.write(str(emb))
    print(time.time())
    