import numpy as np
import pickle as pkl
# from sklearn.cluster import KMeans
from Cluster import kcluster
import time
if __name__ == '__main__':
    ncluster = 176
    print(time.time())
    
    # vfs = pkl.load(open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/cobertvoc.pkl', 'rb'))
    # vocab = list(vfs.keys())
    # vocabvec = [vfs[v] for v in vocab]
    # embarray = np.array(vocabvec)
    
    # clusterid, error, nfound, centers = kcluster (embarray, nclusters=ncluster, dist='u')
    # centers = centers.reshape((ncluster,768))
    # clusterid = list(clusterid)
    # dlabel = {}
    # for i in range(len(vocab)):
    #     dlabel[vocab[i]] = clusterid[i]
    # with open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/funccobert_cluster_76.txt', 'w')as fp:
    #     fp.write(str(dlabel))
    vocab = []
    with open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/kernel-vocab.txt', 'r') as fp:
        lines = fp.readlines()
        for i in range(len(lines))[5:]:
            vocab.append(lines[i].strip())

    with open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/kernel-ft.txt', 'r') as fp:
        vocabvecft = eval(fp.readline().strip())[5:]

    # with open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/openssl-wv.txt', 'r') as fp:
    #     vocabvecwv = eval(fp.readline().strip())[5:]

    assert(len(vocab) == len(vocabvecft))

    embarray = np.array(vocabvecft)
    
    clusterid, error, nfound, centers = kcluster (embarray, nclusters=ncluster, dist='u')
    # centers = centers.reshape((ncluster,768))
    clusterid = list(clusterid)
    dlabel = {}
    for i in range(len(vocab)):
        dlabel[vocab[i]] = clusterid[i]
    with open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/kernel_cluster_176-ft.txt', 'w')as fp:
        fp.write(str(dlabel))
    print(time.time())