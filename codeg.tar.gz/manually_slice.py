import networkx as nx
import pickle as pkl

rootpath = '/home/sise/sda/gyj/NM/411data/727kernel/pdg_vul/'
seedpath = '/home/sise/sda/gyj/NM/411data/727kernel/seed/'
graphpath = '5__s3c2410wdt_probe.pkl'

g = pkl.load(open(rootpath+ graphpath, 'rb'))
# inodes = ['Call@56','Call@5d','Call@4f']
inodes = ['Call@24','Call@c0','Call@c5','Call@da','Call@e6']
subg = g.subgraph(inodes)
seedg = nx.DiGraph()
for ni in subg.nodes():
    seedg.add_node(ni, stm = subg.nodes()[ni]['stm'], type = subg.nodes()[ni]['type'], line = subg.nodes()[ni]['line'])
seedg.add_edges_from(subg.edges())
seedg.add_edges_from([('Call@c0','Call@e6')])
seedg.remove_edges_from([('Call@c5','Call@da'),('Call@da','Call@e6'),('Call@24','Call@da'),('Call@24','Call@c5'),('Call@24','Call@e6')])
# seedg.nodes()['Call@50']['stm'] = '<operator>.lessThan'
g.nodes()['Call@e6']['stm'] = 'clk_get_rate'
# pkl.dump(seedg, open(seedpath+'seed__'+ graphpath, 'wb'))
pkl.dump(seedg, open(seedpath+'seed6__s3c2410wdt_probe.pkl', 'wb'))

# seedpath = '/home/sise/sda/gyj/NM/411data/727kernel/seed/'
# graphpath = 'seed__s3c2410wdt_probe.pkl'
# g = pkl.load(open(seedpath+ graphpath, 'rb'))
# # g.add_node('Return@x', stm = 'return', type='return', line = '0')
# # g.add_node('Call@x', stm = '<operator>.equals', type='opr', line = '0')
# # g.remove_nodes_from(['Call@40','Call@3b','Call@47','Call@39','Call@50'])
# g.add_edges_from([('Call@57','Call@x'),('Call@x','Return@x'),('Call@x','Call@5e')])
# g.remove_edges_from([('Call@57','Call@5e')])
# # g.remove_nodes_from(['Call@e6'])
# g.nodes()['Call@e6']['stm'] = 'clk_get_rate'

# pkl.dump(g, open(seedpath+'seed6__s3c2410wdt_probe.pkl', 'wb'))
