# import numpy as np
# from scipy.cluster.hierarchy import linkage
# from scipy.cluster.hierarchy import fcluster
# from  config import  args
# import pickle

# def clu(vocablist, wdict, max_di):
#     vecterlist = []
#     for w in vocablist:
#         vecterlist.append(wdict[w])
#     wordarrayi = np.array(vecterlist)
#     Zi = linkage(wordarrayi, 'average', metric="cosine")
#     clusters = fcluster(Zi, max_di, criterion='distance')
#     cdict = {}
#     for i in zip(vocablist,clusters):
#         if i[1] in cdict:
#             cdict[i[1]].append(i[0])
#         else:
#             cdict[i[1]] = [i[0]]
#     return cdict

# if __name__ == "__main__":
#     vocab = []
#     finalset = []
#     left = []
#     projectname = args.projectname

#     with open(args.ROOT+'data/'+ str(projectname) +'/vocab.txt', 'r') as fp:
#         lines = fp.readlines()
#         for i in range(len(lines))[5:]:
#             vocab.append(lines[i].strip())

#     with open(args.ROOT+'data/'+ str(projectname) +'/vocab-ft.txt', 'r') as fp:
#         vocabvecft = eval(fp.readline().strip())[5:]

#     with open(args.ROOT+'data/'+ str(projectname) +'/vocab-wv.txt', 'r') as fp:
#         vocabvecwv = eval(fp.readline().strip())[5:]

#     vdict = {}
#     wdict = {}
#     for idx in range(len(vocab)):
#         wdict[vocab[idx]] = vocabvecwv[idx]
#         vdict[vocab[idx]] = vocabvecft[idx]
#         if vocabvecwv[idx]==None:
#             vocabvecwv[idx] = [0 for _ in range(64)]
#             wdict[vocab[idx]] = [0 for _ in range(64)]
#         if vocabvecft[idx] == None:
#             vocabvecft[idx] = [0 for _ in range(64)]
#             vdict[vocab[idx]] = [0 for _ in range(64)]
#         if not (len(wdict[vocab[idx]])==64 and len(vdict[vocab[idx]])==64):
#             print(len(wdict[vocab[idx]]))
#             print(len(vdict[vocab[idx]]))

#     wordarray = np.array(vocabvecwv)

#     max_d = 0.08
#     Z = linkage(wordarray, 'average', metric="cosine")
#     clusters = fcluster(Z, max_d, criterion='distance')
#     d = dict()
#     kpush = 0
#     kput = 0
#     for idx, k in enumerate(clusters):
#         if k in d:
#             d[k].append(vocab[idx])
#         else:
#             d[k] = [vocab[idx]]
#     k = sorted(d, key=lambda k: len(d[k]), reverse=True)
#     l = []
#     for i in k:
#         l.append((i, len(d[i])))
#     print(l)
#     leftset = []
#     for i in l:
#         if i[1]<=1000 and i[1] >=8:
#             dc = d[i[0]]
#             finalset.append(dc)
#             print(len(finalset))
#         elif i[1]<=8:
#             dc = d[i[0]]
#             leftset += dc
#         else:
#             fs = clu(d[i[0]], wdict, 0.05)
#             lll = []
#             for iii in fs:
#                 lll.append(len(fs[iii]))
#             lll = sorted(lll, reverse=True)
#             print(lll)
#             s = len(fs)
#             for fsi in fs:
#                 if len(fs[fsi]) >= 8 and len(fs[fsi]) <= 1000:
#                     finalset.append(fs[fsi])
#                 else:
#                     leftset += fs[fsi]
#     fs = clu(leftset, vdict, 0.3)
#     lll = []
#     for iii in fs:
#         lll.append(len(fs[iii]))
#     lll = sorted(lll, reverse=True)
#     print(lll)
#     s = len(fs)
#     for fsi in fs:
#         finalset.append(fs[fsi])
#     print(len(finalset))
#     vocabvecft = finalset
#     d = {}

#     for idx,i in enumerate(vocabvecft):
#         for t in vocabvecft[idx]:
#             d[t] =idx


#     with open(args.ROOT+'data/'+ str(projectname) +'/funcname_cluster_1056.pkl','wb')as fp:
#         pickle.dump(d,fp)

from sklearn.cluster import KMeans
import numpy as np
import time

print(time.time())

with open('/home/sise/sda/gyj/NM/graphdomain_openssl/timetest/vlc-ft.txt', 'r')as fp:
    ft = eval(fp.read())
X = np.array(ft)
kmeans = KMeans(n_clusters=76).fit(X)
print(time.time())
