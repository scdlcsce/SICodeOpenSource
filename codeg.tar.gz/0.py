import pickle as pkl
import networkx as nx
a = pkl.load(open('/home/sise/sda/gyj/NM/411data/712kernel/seed/seed__11__sja1110_rcv_inband_control_extension.pkl', 'rb'))
# b = pkl.load(open('/home/sise/sda/gyj/NM/graphdomain_openssl/g2.pkl', 'rb'))
print('d')
# a.remove_node('Call@94')
# pkl.dump(a, open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/asn1_print_info-refine.pkl', 'wb'))
# n, g = pkl.load(open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/subgraph-noremove.pkl', 'rb'))

# for i in range(len(n)):
#     if n[i] == '844__util_flags_Call@108':
#         gi = g[i]
#         print('d')
