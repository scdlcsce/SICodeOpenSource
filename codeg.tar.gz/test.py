import pickle as pkl
import argparse
import os
from tqdm import tqdm
from datetime import datetime
import numpy as np
import torch
import modeldatatest100 as modeldata
import models
import utils
from utils import DupStdoutFileManager

from config import parse_encoder

seed = 2
np.random.seed(seed)
torch.random.manual_seed(seed)

def validation(args, model, vdata_source):
    for nodenum in range(6, 100):
        if not nodenum in vdatasource:
            continue
        loaders = vdata_source.gen_data_loaders(50, 20)
        p_preds = []
        n_preds = []
        for batch_i in loaders:
            pos_l, pos_s, neg_l, neg_s = vdata_source.gen_batch(batch_i, nodenum)
            with torch.no_grad():
                emb_pos_l = model.emb_model(pos_l)
                emb_pos_s = model.emb_model(pos_s)
                emb_neg_l = model.emb_model(neg_l)
                emb_neg_s = model.emb_model(neg_s)

            p_pred = model.predict(emb_pos_l, emb_pos_s)
            n_pred = model.predict(emb_neg_l, emb_neg_s)
            p_preds.append(p_pred)
            n_preds.append(n_pred)
        p_preds = torch.cat(p_preds)
        n_preds = torch.cat(n_preds)
        avg_p = (torch.sum(p_preds) / 1000).item()
        avg_n = (torch.sum(n_preds) / 1000).item()
        p_preds = p_preds.cpu().tolist()
        n_preds = n_preds.cpu().tolist()

        # t = 0.4
        t = round((avg_n - avg_p)/10 + avg_p, 4)

        tpcount = len([p for p in p_preds if p <= t])
        fncount = len([p for p in p_preds if p > t])
        tncount = len([n for n in n_preds if n > t])
        fpcount = len([n for n in n_preds if n <= t])

        print('node = {}, avg_p = {:.4f}, avg_n = {:.4f}, t = {}, tp = {}, fn = {}, tn = {}, fp = {}'.format(nodenum, avg_p, avg_n,t,tpcount,fncount,tncount,fpcount))

if __name__ == '__main__':
    model_path = '/home/sise/sda/gyj/NM/graphdomain_openssl/E1/ckpt/params_070_79n.pt'
    parser = (argparse.ArgumentParser(description='Order embedding arguments'))
    utils.parse_optimizer(parser)
    parse_encoder(parser)
    args = parser.parse_args()
    now_time = datetime.now().strftime('%Y-%m-%d-%H-%M-%S')
    with DupStdoutFileManager('/home/sise/sda/gyj/NM/graphdomain_openssl/E1/log/test-' + now_time + '.log') as _:
        print(model_path)
        vdatasource = pkl.load(open('/home/sise/sda/gyj/NM/graphdomain_openssl/E1/samples/testdict.pkl', 'rb'))
        vdata_source = modeldata.DiskDataSource(vdatasource)
        model = models.OrderEmbedder(args)
        model.to(utils.get_device())
        model.load_state_dict(torch.load(model_path))
        model.eval()
        validation(args, model, vdata_source)