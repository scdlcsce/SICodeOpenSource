
import random as rd
import networkx as nx


import utils

rd.seed(2)
inputdim = 50
wvec_dim = 27


class DiskDataSource:

    def __init__(self, dataset):
        self.dataset = dataset

    def gen_data_loaders(self, batch_num, batch_size):
        loaders = [batch_size]* batch_num
        return loaders

    def gen_batch(self, batch_i, nodenum):
        batch_size = batch_i
        trainset = self.dataset[nodenum]

        pos_s_list, pos_l_list, neg_s_list, neg_l_list = [], [], [], []

        for i in range(batch_size):
            ancnum = rd.choice(list(range(3, min(10, nodenum - 1))))

            sample = rd.choice(trainset)

            types = sample[1]
            edge = [eval(e) for e in sample[2]]

            ns = [rd.choice(list(range(wvec_dim))) 
                        if types[nidx] == 'api' 
                        else rd.choice(list(range(wvec_dim,inputdim)))
                        for nidx in range(0,nodenum)]
            
            gpl = nx.Graph()
            for ni in range(0,nodenum):
                gpl.add_node('n_'+str(ni), label = ns[ni])
            for ei in edge:
                gpl.add_edge('n_'+str(ei[0]), 'n_'+str(ei[1]))

            alist = list(range(0,ancnum))
            e = [i for i in edge if i[0] < ancnum and i[1] < ancnum]
            gps = nx.Graph()
            for ni in alist:
                gps.add_node('n_'+str(ni), label = ns[ni])
            for ei in e:
                gps.add_edge('n_'+str(ei[0]), 'n_'+str(ei[1]))

            pos_s_list.append(gps)
            pos_l_list.append(gpl)

            ancapi = [ni for ni in ns[:ancnum] if ni < wvec_dim]
            ancopr = [ni for ni in ns[:ancnum] if ni >= wvec_dim]

            sample = rd.choice(trainset)
            types = sample[1]
            edge = [eval(e) for e in sample[2]]
            
            napi = [rd.choice(list(range(wvec_dim))) for nidx in range(0,len(types)) if types[nidx] == 'api' ]
            nopr = [rd.choice(list(range(wvec_dim, inputdim))) for nidx in range(0,len(types)) if types[nidx] is not 'api' ]

            napi = ancapi + napi[len(ancapi):]
            rd.shuffle(napi)
            nopr = ancopr + nopr[len(ancopr):]
            rd.shuffle(nopr)

            napicount = 0
            noprcount = 0
            nns = []
            for idx in range(len(types)):
                t = types[idx]
                if t == 'api':
                    nns.append(napi[napicount])
                    napicount += 1
                else:
                    nns.append(nopr[noprcount])
                    noprcount += 1


            nlist = list(range(0,nodenum))
            gnl = nx.Graph()
            for ni in nlist:
                gnl.add_node('n_'+str(ni), label = nns[ni])
            for ei in e:
                gnl.add_edge('n_'+str(ei[0]), 'n_'+str(ei[1]))
            neg_l_list.append(gnl)

        pos_s = utils.batch_nx_graphs(pos_s_list)
        neg_s = pos_s
        pos_l = utils.batch_nx_graphs(pos_l_list)
        neg_l = utils.batch_nx_graphs(neg_l_list)
        return pos_l, pos_s, neg_l, neg_s
