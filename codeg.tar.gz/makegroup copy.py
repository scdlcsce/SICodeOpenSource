import pickle as pkl
import networkx as nx
import itertools
import re

def getlayer(astlines, lidx, layer): #lidx行及其下属节点
    nextcompound = None
    for idx in range(lidx+1, len(astlines)):
        if astlines[idx].count('\t') <= layer:
            nextcompound = idx
            break
    if nextcompound == None:
        return lidx+1, len(astlines)+1
    return lidx, nextcompound

def getnum(astlines, lidx, layer):
    r_start, r_stop = getlayer(astlines, lidx, layer)
    linenums = []
    for idx in range(lidx, r_stop):
        l = astlines[idx]
        ltoken = l.split(':')
        if len(ltoken) <2:
            continue
        if ltoken[0].strip() == 'None':
            continue
        linenums.append(ltoken[0].strip())
    linenums = sorted(list(set(linenums)))
    linenums = [l+'@'+str(layer) for l in linenums]
    # if len(linenums) == 1:
    #     return linenums[0]
    return linenums

def getpart(astlines, lidx, layer):
    r_start, r_stop = getlayer(astlines, lidx, layer)
    linenums = []
    for idx in range(r_start, r_stop):
        if astlines[idx].count('\t') == layer+1:
            linenums.append(idx)
    
    return linenums

def fixlayer(asttype, layer):
    asttype = str(asttype)
    ls = list(set(re.findall(r'@[0-9]*\'', asttype)))
    ls = sorted([int(l[1:-1]) for l in ls])
    for l in ls:
        asttype = asttype.replace('@'+str(l)+'\'', '@'+str(l+layer)+'\'')
    return eval(asttype)


def getcompound(astlines, linerange, layer):
    asttype = []
    lidx = linerange[0]
    while(lidx < linerange[1]+1):
    # for lidx in range(linerange[0],linerange[1]+1):
        l = astlines[lidx]
        ltoken = l.split(':')
        if len(ltoken) <2:
            lidx += 1
            continue
        if not l.count('\t') == layer:
            lidx += 1
            continue
        linenum, linetype = ltoken[0].strip(), ltoken[1].strip()
        if linenum == 'None':
            lidx += 1
            continue
        if linetype in ['IdentifierDeclStatement', 'ExpressionStatement', 'ReturnStatement']:
            nums = getnum(astlines, lidx, layer)
            asttype += nums
        elif linetype == 'CompoundStatement':
            compoundrange = getlayer(astlines, lidx, layer)
            asttype.append(getcompound(astlines, compoundrange, layer+1)) 
        elif linetype == 'IfStatement':
            ifparts = getpart(astlines, lidx, layer)
            ifcondition = getnum(astlines, ifparts[0], layer+1)
            if len(ifcondition) == 1:
                ifcondition = ifcondition[0]
            ifexpressionrange = getlayer(astlines, ifparts[1], layer+1)
            ifexpression = getcompound(astlines, ifexpressionrange, layer+1)
            iflines = ['if@'+str(layer+1), ifcondition, ifexpression]
            asttype.append(iflines) 
        elif linetype == 'WhileStatement':
            whileparts = getpart(astlines, lidx, layer)
            whilecondition = getnum(astlines, whileparts[0], layer+1)
            if len(whilecondition) == 1:
                whilecondition = whilecondition[0]
            whileexpressionrange = getlayer(astlines, whileparts[1], layer+1)
            whileexpression = getcompound(astlines, whileexpressionrange, layer+1)
            asttype.append(['while@'+str(layer+1), whilecondition, whileexpression])
        elif linetype == 'ForStatement':
            forparts = getpart(astlines, lidx, layer)
            forexpressions = []
            for p in forparts:
                forexpressionrange = getlayer(astlines,p, layer+1)
                forexpression = getcompound(astlines, forexpressionrange, layer+1)
                if len(forexpression) == 1:
                    forexpression = forexpression[0]
                forexpressions.append(forexpression)
            asttype.append(['for@'+str(layer+1)] + forexpressions) #
        elif linetype == 'DoStatement':
            doparts = getpart(astlines, lidx, layer)
            doexpressions = []
            for p in doparts:
                doexpressionrange = getlayer(astlines,p, layer+1)
                doexpression = getcompound(astlines, doexpressionrange, layer+1)
                if len(doexpression) == 1:
                    doexpression = doexpression[0]
                doexpressions.append(doexpression)
            asttype.append(['do@'+str(layer+1)] + doexpressions) #
        elif linetype == 'SwitchStatement':
            switchparts = getpart(astlines, lidx, layer)
            switchcondition = getnum(astlines, switchparts[0], layer+1)
            if len(switchcondition) == 1:
                switchcondition = switchcondition[0]
            switchexpressionrange = getlayer(astlines, switchparts[1], layer+1)
            switchexpression = getcompound(astlines, switchexpressionrange, layer+1)
            switchlines = ['switch@'+str(layer+1), switchcondition, switchexpression]
            asttype.append(switchlines) 
        elif linenum == 'ElseStatement':
            elseexpressionrange = getlayer(astlines, lidx+1, layer)
            elseexpression = getcompound(astlines, elseexpressionrange, layer)
            elseexpression = fixlayer(elseexpression, 2)
            # elseexpression = getcompound(astlines, elseexpressionrange, layer+1)
            ifelselines = asttype[-1] + [elseexpression]
            asttype = asttype[:-1] + [ifelselines]
            lidx = elseexpressionrange[1] - 1
        else:
            if not linenum in asttype:
                asttype.append(linenum+'@'+str(layer))
        lidx += 1
    if len(asttype) == 1:
        return asttype[0]
    return asttype


# def g_sample_group(tgraph, n_cent, hopsize):
#     count = 0
#     sucedge  = []
#     n1 = [n_cent]
#     n2 = [n_cent]
#     while count < hopsize :
#         count += 1
#         suc = []
#         for ni in n1:
#             sucnode = list(tgraph.successors(ni))
#             suc += sucnode
#             sucedge += [(ni, s) for s in sucnode]
#         newnode = []
#         for s in suc:
#            if not s in n1:
#                 newnode.append(s)
#         if len(newnode) == 0:
#             break
#         n1 += newnode
#     nsus_cfg, edgesus_cfg = n1, sucedge
#     count = 0
#     preedge  = []
#     while count < hopsize:
#         count += 1
#         pre = []
#         for ni in n2:
#             prenode = list(tgraph.predecessors(ni))
#             pre += prenode
#             preedge += [(p, ni) for p in prenode]
#         newnode = []
#         for p in pre:
#             if not p in n2:
#                 newnode.append(p)
#         if len(newnode) == 0:
#             break
#         n2 += newnode
#     npre_cfg, edgepre_cfg = n2, preedge
#     g = nx.Graph()
#     nodes = [n_cent] + list(set(nsus_cfg + npre_cfg))
#     for n in nodes:
#         g.add_node(n, line = tgraph.nodes()[n]['line'], type = tgraph.nodes()[n]['type'], stm = tgraph.nodes()[n]['stm'])

#     for e in edgesus_cfg:
#         g.add_edge(e[0], e[1], type = tgraph.edges()[e]['type'])
#     for e in edgepre_cfg:
#         g.add_edge(e[0], e[1], type = tgraph.edges()[e]['type'])
#     return g


# def g_sample_group(path):
#     with open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/code/packet-eap.c.ast', 'r')as fp:
#         astlines = fp.readlines()
#     pdg = pkl.load(open('/home/sise/sda/gyj/NM/graphdomain_openssl/dissect_eap_identity_wlan.pkl', 'rb'))




if __name__ == '__main__':

    with open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/codebase_a/providers/implementations/keymgmt/mac_legacy_kmgmt.c.ast', 'r')as fp:
        astlines = fp.readlines()

    for lidx, l in enumerate(astlines):
        ltoken = l.split(':')
        if len(ltoken)<3:
            continue
        if l.split(':')[1] == 'FunctionDef' and l.split(':')[2].split(' ')[0] == 'mac_match':
            compoundlayer = 1
            c_start = lidx+1
            compoundrange = getlayer(astlines, c_start, 1)
            asttype = getcompound(astlines, (compoundrange[0]+1, compoundrange[1]), compoundlayer+1)

    print(asttype)

    # pdg = pkl.load(open('/home/sise/sda/gyj/NM/graphdomain_openssl/dissect_eap_identity_wlan.pkl', 'rb'))
    # nodeline = [{n : pdg.nodes()[n]['line']} for n in pdg.nodes()]
    # linenode = itertools.groupby(nodeline, lambda x:list(x.items())[0][1])
    # linenode = {i[0]:[list(j.keys())[0] for j in i[1]] for i in linenode}
    
    # for n in list(pdg.nodes()):


