import argparse
import sys
# sys.path.append('/home/sise/sda/gyj/NM/openssl_increase/common')
from modeldata import load_dataset, DiskDataSource
import models
import utils
from utils import DupStdoutFileManager
import pickle as pkl
from config import parse_encoder
from collections import defaultdict
from datetime import datetime
from sklearn.metrics import roc_auc_score, confusion_matrix
from sklearn.metrics import precision_recall_curve, average_precision_score
import torch

USE_ORCA_FEATS = False # whether to use orca motif counts along with embeddings
MAX_MARGIN_SCORE = 1e9 # a very large margin score to given orca constraints

def validation(args, model, data_source):
    all_raw_preds, all_preds, all_labels = [], [], []
    loaders = data_source.gen_data_loaders(10 * args.batch_size, args.batch_size)
    for batch_i in loaders:
        ganchor, gtest, label = data_source.gen_batch(batch_i, False, 0)
        labels = [1 if l == 0 else 0 for l in label]
        labels = torch.tensor(labels).to(utils.get_device()) 
        with torch.no_grad():
            emb_ganchor, emb_gtest = (model.emb_model(ganchor), model.emb_model(gtest))
        raw_pred = model.predict(emb_ganchor, emb_gtest)
        pred = torch.tensor([0 if p>0.4  else 1 for p in raw_pred]).to(utils.get_device()) 
        # pred = model.clf_model(raw_pred.unsqueeze(1)).argmax(dim=-1)
         
        all_raw_preds.append(raw_pred)
        all_preds.append(pred)
        all_labels.append(labels)
    pred = torch.cat(all_preds, dim=-1)
    labels = torch.cat(all_labels, dim=-1)
    raw_pred = torch.cat(all_raw_preds, dim=-1)
    acc = torch.mean((pred == labels).type(torch.float))
    prec = (torch.sum(pred * labels).item() / torch.sum(pred).item() if
        torch.sum(pred) > 0 else float("NaN"))
    recall = (torch.sum(pred * labels).item() /
        torch.sum(labels).item() if torch.sum(labels) > 0 else
        float("NaN"))
    labels = labels.detach().cpu().numpy()
    raw_pred = raw_pred.detach().cpu().numpy()
    pred = pred.detach().cpu().numpy()
    auroc = roc_auc_score(labels, raw_pred)
    avg_prec = average_precision_score(labels, raw_pred)
    tn, fp, fn, tp = confusion_matrix(labels, pred).ravel()

    print("Validation. Acc: {:.4f}. "
        "P: {:.4f}. R: {:.4f}. AUROC: {:.4f}. AP: {:.4f}. TN: {}. FP: {}. FN: {}. TP: {}".format(
            acc, prec, recall, auroc, avg_prec,
            tn, fp, fn, tp))
    print("{}\n".format(str(datetime.now())))

if __name__ == "__main__":
    model_path = '/home/sise/sda/gyj/NM/openssl_increase/ckpt/params_038_100l_-3_128.pt'
    parser = (argparse.ArgumentParser(description='Order embedding arguments'))
    utils.parse_optimizer(parser)
    parse_encoder(parser)
    args = parser.parse_args()
    now_time = datetime.now().strftime('%Y-%m-%d-%H-%M-%S')
    with DupStdoutFileManager('/home/sise/sda/gyj/NM/openssl_increase/runs/test-' + now_time + '.log') as _:
        vdatasource = pkl.load(open('/home/sise/sda/gyj/NM/data/sampledict4.pkl', 'rb'))
        vdata_source = DiskDataSource(load_dataset(vdatasource))
        model = models.OrderEmbedder(args)
        model.to(utils.get_device())
        model.load_state_dict(torch.load(model_path))
        model.eval()
        validation(args, model, vdata_source)