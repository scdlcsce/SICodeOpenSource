import  torch
import argparse
import pickle
import  numpy as np
from config import parse_encoder
from modeldata50 import DiskDataSource
import models
import utils
from tqdm import tqdm
import numpy as np
from tqdm import tqdm
import pickle as pkl


def build_model(args):
    model = models.OrderEmbedder(args)
    model.to(utils.get_device())
    return model

seed = 123
np.random.seed(seed)
torch.random.manual_seed(seed)

if __name__ == "__main__":
    parser = (argparse.ArgumentParser(description='Order embedding arguments'))
    utils.parse_optimizer(parser)
    parse_encoder(parser)
    args = parser.parse_args() 
    with open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/subgraph-remove-node.pkl', 'rb') as fp:
        [namelist, subgraphlist, featslist] = pickle.load(fp)

    # model_path = '/home/sise/sda/gyj/NM/openssl_increase/ckpt_100/params_026_71n.pt'
    model_path = '/home/sise/sda/gyj/NM/graphdomain_openssl/E1/ckpt/params_070_79n.pt'
    model = models.OrderEmbedder(args)
    model.to(utils.get_device())
    model.load_state_dict(torch.load(model_path))
    model.eval()

    emb_S = []
    Sdata_source = DiskDataSource(subgraphlist)
    loaders = Sdata_source.gen_retrieval_loaders(len(subgraphlist), args.batch_size )
    for batch_i in tqdm(loaders):
        g = Sdata_source.gen_retrieval_batch(batch_i)
        with torch.no_grad():
            emb_g = model.emb_model(g)
        emb_S += emb_g
    assert(len(namelist) == len(emb_S))
    emb_S = torch.stack(emb_S)
    emb_S = emb_S.cpu().detach()
    pkl.dump([namelist, emb_S, featslist], open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/NMemb-noremove.pkl', 'wb'))