import argparse
from config import parse_encoder
from gutils import g_sample
import utils
from tqdm import tqdm
import os
from tqdm import tqdm
import pickle as pkl
import numpy as np
import time
import  torch
import argparse
import  numpy as np
from config import parse_encoder
from modeldata50 import DiskDataSource
import models
import utils
from tqdm import tqdm
import numpy as np
from tqdm import tqdm
import pickle as pkl

input_dim = 100
wvec_dim = 76
opr_dim = 22


def build_model(args):
    model = models.OrderEmbedder(args)
    model.to(utils.get_device())
    return model

seed = 123
np.random.seed(seed)
torch.random.manual_seed(seed)


with open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/funccobert_cluster_76-ft.txt', 'r') as fp:
    ldict = eval(fp.read())

def build_model(args):
    model = models.OrderEmbedder(args)
    model.to(utils.get_device())
    return model

seed = 123
np.random.seed(seed)
torch.random.manual_seed(seed)

code2type = { 
    '<operator>.plus':                          0,
    '<operator>.addition':                      0,
    '<operator>.subtraction':                   1,
    '<operator>.multiplication':                2,
    '<operator>.division':                      3,
    '<operator>.modulo':                        4,
    '<operator>.or':                           5,
    '<operator>.and':                           6,
    '<operator>.not':                           7,
    '<operator>.shiftRight':                    8,
    '<operators>.LogicalShifRight':             8,
    '<operator>.arithmeticShiftRight':          8,
    '<operator>.arithmeticShiftLeft':           8,
    '<operator>.shiftLeft':                     8,
    '<operator>.equals':                        9,
    '<operator>.notEquals':                     10,
    '<operator>.lessEqualsThan':                11,
    '<operator>.lessThan':                      11,
    '<operator>.greaterEqualsThan':             12,
    '<operator>.greaterThan':                   12,
    '<operator>.logicalNot':                    13,
    '<operator>.logicalOr':                     14,
    '<operator>.logicalAnd':                    15,
    '<operator>.sizeOf':                        16,
    '<operator>.addressOf':                     17,
    # --- drop ---
    '<operator>.minus':                         18, 
    '<operator>.cast':                          19,
    '<operator>.indirectMemberAccess':          20,          
    '<operator>.computedMemberAccess':          20,
    '<operator>.indirection':                   20,
    '<operator>.memberAccess':                  20,
    '<operator>.assignment':                    21,
}

def g2feats(g):
    feat = np.zeros(input_dim)
    gnode = list(g.nodes())
    for n in gnode:
        callstm = g.nodes()[n]["stm"]
        calltype = g.nodes()[n]["type"]
        if calltype == 'api':
            try:
                label = ldict[callstm]
            except Exception:
                label = input_dim - 1
            gvec = label
        elif calltype == 'opr':
            label = code2type[callstm]
            gvec = wvec_dim + label
        elif calltype == 'return': 
            gvec = input_dim - 2
        elif calltype == 'block':
            gvec = input_dim - 1
        feat[gvec] += 1
        g.nodes()[n]['label'] = gvec
    for e in list(g.edges()):
        del g.edges()[e]['type']

    return feat, g

if __name__ == "__main__":
    print(time.time())
    parser = (argparse.ArgumentParser(description='Order embedding arguments'))
    utils.parse_optimizer(parser)
    parse_encoder(parser)
    args = parser.parse_args()
    pdg_path = '/home/sise/sda/gyj/NM/graphdomain_openssl/timetest/openssl_gexf/'
    funnames = [ p for p in list(os.walk(pdg_path))[0][2] if '.pkl' in p]

    model_path = '/home/sise/sda/gyj/NM/graphdomain_openssl/E8/ckpt/params_100.pt'
    model = models.OrderEmbedder(args)
    model.to(utils.get_device())
    model.load_state_dict(torch.load(model_path))
    model.eval()


    for i in range(len(funnames) // 20000 + 1):
        beginidx = 20000 * i
        namelist = []
        featslist = []
        encg = []
        for j in tqdm(range(beginidx, min(beginidx + 20000, len(funnames)))):
            fname = funnames[j]
            pgraph = pkl.load(open(pdg_path+fname, 'rb'))
            for n in list(pgraph.nodes()):
                if 'MethodReturn' in n or 'Method' in n:
                    pgraph.remove_node(n)
            apilist = [ni for ni in list(pgraph.nodes()) if pgraph.nodes()[ni]['type'] == 'api']
            for n in apilist:
                # subc = g_sample_group(pgraph ,n, 4, ast)
                subc = g_sample(pgraph ,n, 4)
                if subc == None:
                    continue
                # subc = removeassign(subc) # pdg4
                if len(list(subc.edges())) == 0:
                    continue
                if len(list(subc.nodes())) < 3:
                    continue
                # subgraphlist.append(subc)
                # lenlist.append(len(list(subc.nodes())))
                r1, r2 = g2feats(subc)
                namelist.append(fname[:-4]+'_'+n)
                featslist.append(r1)
                encg.append(r2)

        emb_S = []
        Sdata_source = DiskDataSource(encg)
        loaders = Sdata_source.gen_retrieval_loaders(len(encg), args.batch_size )
        for batch_i in tqdm(loaders):
            g = Sdata_source.gen_retrieval_batch(batch_i)
            with torch.no_grad():
                emb_g = model.emb_model(g)
            emb_S += emb_g
        # assert(len(namelist) == len(emb_S))
        emb_S = torch.stack(emb_S)
        emb_S = emb_S.cpu().detach()

        path = '/home/sise/sda/gyj/NM/graphdomain_openssl/timetest/openssl-emb.pkl'
        pkl.dump([namelist, emb_S, featslist], open(path, 'wb'))
    print(time.time())
