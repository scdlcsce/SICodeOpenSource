with open('/home/sise/sda/gyj/NM/graphdomain_openssl/vflog', 'r')as fp:
    vflog= fp.readlines()
starttimes = []
endtimes = []
for v in vflog:
    if 'vf start:' in v:
        starttimes.append(float(v.split(':')[1].strip()))
    if 'vf end:' in v:
        endtimes.append(float(v.split(':')[1].strip()))
t_all = 0.0
for i in range(len(starttimes)):
    t_all += endtimes[i] - starttimes[i]
print(t_all)