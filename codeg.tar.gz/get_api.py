import argparse
from config import parse_encoder
import utils
from tqdm import tqdm
import os
from tqdm import tqdm
import pickle as pkl


if __name__ == "__main__":
    parser = (argparse.ArgumentParser(description='Order embedding arguments'))
    utils.parse_optimizer(parser)
    parse_encoder(parser)
    args = parser.parse_args()
    pdg_path = '/home/sise/sda/gyj/NM/graphdomain_openssl/E5/pdg/'
    funnames = [ p for p in list(os.walk(pdg_path))[0][2] if '.pkl' in p]

    apilist = []
    oprlist = []
    assignlist = []
    returnlist = []
    
    for fname in tqdm(funnames):
        pgraph = pkl.load(open(pdg_path+fname, 'rb'))

        for n in list(pgraph.nodes()):
            if pgraph.nodes()[n]['type'] == 'api':
                apilist.append(pgraph.nodes()[n]['stm'])
            elif pgraph.nodes()[n]['type'] == 'opr':
                if pgraph.nodes()[n]['stm'] == '<operator>.assignment':
                    assignlist.append('assign')
                else:
                    oprlist.append('opr')
            elif pgraph.nodes()[n]['type'] == 'return':
                returnlist.append('return')
    print(len(apilist), len(oprlist), len(assignlist), len(returnlist))
    # 0.25	0.5	0.2	0.05
    
    apilist = list(set(apilist))
    # a = apilist.index('bio_f_nbio_test')
    pkl.dump(apilist, open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/api.pkl', 'wb'))
