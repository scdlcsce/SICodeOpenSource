import sys
import argparse
sys.path.append('/home/sise/sda/gyj/NM/openssl_increase/common')
import data
import models
import utils
from config import parse_encoder
from utils import DupStdoutFileManager
from collections import defaultdict
from datetime import datetime
from sklearn.metrics import roc_auc_score, confusion_matrix
from sklearn.metrics import precision_recall_curve, average_precision_score
import torch
import pickle as pkl
from tqdm import tqdm

USE_ORCA_FEATS = False # whether to use orca motif counts along with embeddings
MAX_MARGIN_SCORE = 1e9 # a very large margin score to given orca constraints

def retrieval(args, model, S, T):
    emb_S, emb_T = [], []
    all_preds = {}
    Sdata_source = data.DiskDataSource(S)
    loaders = Sdata_source.gen_retrieval_loaders(len(S), args.batch_size )
    for batch_i in tqdm(loaders):
        g = Sdata_source.gen_retrieval_batch(batch_i)
        with torch.no_grad():
            emb_g = model.emb_model(g)
        emb_S += emb_g
        
    Tdata_source = data.DiskDataSource(T)
    loaders = Tdata_source.gen_retrieval_loaders(len(T), args.batch_size )
    for batch_i in tqdm(loaders):
        g = Tdata_source.gen_retrieval_batch(batch_i)
        with torch.no_grad():
            emb_g = model.emb_model(g)
        emb_T += emb_g

    emb_T = torch.stack(emb_T)
    emb_S = torch.stack(emb_S)

    for sidx, s in enumerate(emb_S):
        s = s.expand(emb_T.shape)
        raw_pred = model.predict(emb_T, s)
        # pred = raw_pred
        pred = torch.tensor([0 if p>args.margin else 1 for p in raw_pred]).to(utils.get_device()) 
        # pred = model.clf_model(raw_pred.unsqueeze(1))
        pospred = model.predict(s, emb_T)
        label = pred
        # label2 = torch.where(pred[:,1]>-2e-2, 1, 0)
        # print(sum(label))
        # score = {i: float(pred[i][1].cpu().detach()) for i in range(int(label.shape[0])) if label[i]>0 and label2[i] > 0 }
        score = {i: float(pospred[i].cpu().detach()) for i in range(int(label.shape[0])) if label[i]>0}
        score = sorted(score.items(), key=lambda d: d[1], reverse=False)
        # score = sorted(score.items(), key=lambda d: d[1], reverse=True)
        all_preds[str(sidx)] = score
        print(sidx, score)


    # pred = torch.cat(all_preds, dim=-1)
    # acc = torch.mean((pred == labels).type(torch.float))
    # prec = (torch.sum(pred * labels).item() / torch.sum(pred).item() if
    #     torch.sum(pred) > 0 else float("NaN"))
    # recall = (torch.sum(pred * labels).item() /
    #     torch.sum(labels).item() if torch.sum(labels) > 0 else
    #     float("NaN"))
    # labels = labels.detach().cpu().numpy()
    # raw_pred = raw_pred.detach().cpu().numpy()
    # pred = pred.detach().cpu().numpy()
    # auroc = roc_auc_score(labels, raw_pred)
    # avg_prec = average_precision_score(labels, raw_pred)
    # tn, fp, fn, tp = confusion_matrix(labels, pred).ravel()

    # print("\n{}".format(str(datetime.now())))
    # print("Validation. Acc: {:.4f}. "
    #     "P: {:.4f}. R: {:.4f}. AUROC: {:.4f}. AP: {:.4f}. TN: {}. FP: {}. FN: {}. TP: {}".format(
    #         acc, prec, recall, auroc, avg_prec,
    #         tn, fp, fn, tp))

if __name__ == "__main__":
    parser = (argparse.ArgumentParser(description='Order embedding arguments'))
    utils.parse_optimizer(parser)
    parse_encoder(parser)
    args = parser.parse_args()
    now_time = datetime.now().strftime('%Y-%m-%d-%H-%M-%S')
    model_path = '/home/sise/sda/gyj/NM/openssl_increase/ckpt/params_035_39l_128.pt'
    torch.cuda.set_device(1)
    model = models.OrderEmbedder(args)
    model.to(utils.get_device())
    model.load_state_dict(torch.load(model_path))
    model.eval()
    with open('/home/sise/sda/gyj/NM/data/testing.pkl', 'rb') as fid:
        testingset = pkl.load(fid)
    S = testingset[0]
    T = testingset[1]
    with DupStdoutFileManager('/home/sise/sda/gyj/NM/openssl_increase/runs/ranking-' + now_time + '.log') as _:
        print(model_path)
        retrieval(args, model, S, T)