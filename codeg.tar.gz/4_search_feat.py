import  torch
import argparse
from config import parse_encoder
import models
from gutils import getgraph, makeBlock, normGraph, seed2g, gmerge, g2feats
import utils
from datetime import datetime
from tqdm import tqdm
import json
from tqdm import tqdm
import pickle as pkl
import numpy as np

input_dim = 100
wvec_dim = 77

def build_model(args):
    model = models.OrderEmbedder(args)
    model.to(utils.get_device())
    return model


if __name__ == "__main__":

    seedfile = 'asn1_parse'
    seedfunc = 'asn1_print_info'
    vinfo = eval("[[45],'BIO_new']")
    vinfo = (vinfo[0], vinfo[1].lower())
    hopsize = 4

    with open('/home/sise/sda/gyj/NM/openssl_increase/data/funccobert_cluster_77.txt', 'r') as fid:
        ldict = eval(fid.read())
    filedir='/mnt/sdc/gyj/bakNM/NMgraph-one/data/openssl/code/vul/'+seedfile
    # filedir='/home/sise/sda/gyj/bakNM/NMgraph-one/data/openssl/code/vul/'+seedfile
    with open(filedir+'_cfg.json','r') as fp:
        jdata = json.load(fp)
    with open(filedir+'_pdg.json','r') as fp:
        pdata = json.load(fp)
    funccfg = None
    funcpdg = None
    for f in jdata['functions']:
        if f['function'] == seedfunc:
            funccfg = f['CFG']
    for f in pdata['functions']:
        if f['function'] == seedfunc:
            funcpdg = f['PDG']
    if funccfg == None or funcpdg == None:
        print("Function cannot find.")
        exit()
    
    cfg1, pdg1 = getgraph(seedfunc, funccfg, funcpdg)
    cfg2 = makeBlock(cfg1)
    pdg2 = makeBlock(pdg1)
    cfg = normGraph(cfg2, 'cfg')
    pdg = normGraph(pdg2, 'pdg')

    cdg_seed, ddg_seed, pdg_cent = seed2g(pdg, vinfo[0], vinfo[1], hopsize, 'pdg')
    cfg_seed, cfg_cent, _ = seed2g(cfg, vinfo[0], vinfo[1], hopsize, 'cfg')

    assert pdg_cent == cfg_cent
    assert not pdg_cent == None

    g_seed = gmerge(pdg_cent, cfg_seed, cdg_seed, ddg_seed)
    
    feat, g = g2feats(g_seed, ldict, input_dim, wvec_dim)

    [namelist, subgraphlist, featslist] = pkl.load(open('/home/sise/sda/gyj/NM/openssl_increase/data/subgraph_100.pkl', 'rb'))

    featslist =np.asarray(featslist)
    idxs = np.where(np.min(featslist - feat,axis = 1)>=0)[0]
    s_namelist = [namelist[i] for i in idxs.tolist()]
    with open('/home/sise/sda/gyj/NM/openssl_increase/subgraph_matching/log','w')as fp:
        fp.write(str(s_namelist))