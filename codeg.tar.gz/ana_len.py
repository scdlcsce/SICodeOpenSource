import pickle as pkl
a = pkl.load(open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/subgraph-noremove.pkl', 'rb'))
lens = [len(i.nodes()) for i in a[1]]

for i in range(10, max(lens)):
    try:
        print(i, 100*len([j for j in lens if j <= i ])/len(lens))
    except Exception:
        pass