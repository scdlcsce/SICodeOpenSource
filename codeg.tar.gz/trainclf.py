"""Train the order embedding model"""

# # Set this flag to True to use hyperparameter optimization
# # We use Testtube for hyperparameter tuning
# HYPERPARAM_SEARCH = False
# HYPERPARAM_SEARCH_N_TRIALS = None   # how many grid search trials to run
#                                     #    (set to None for exhaustive search)
import pickle as pkl

import argparse
from itertools import permutations
import pickle
import os
import random
import time
import sys
from tqdm import tqdm
from deepsnap.batch import Batch
import networkx as nx
from datetime import datetime
import numpy as np
from sklearn.manifold import TSNE
import torch
import torch.nn as nn
import torch.multiprocessing as mp
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.tensorboard import SummaryWriter
from torch_geometric.data import DataLoader
from torch_geometric.datasets import TUDataset
import torch_geometric.utils as pyg_utils
import torch_geometric.nn as pyg_nn
from sklearn.metrics import roc_auc_score, confusion_matrix
from sklearn.metrics import precision_recall_curve, average_precision_score
sys.path.append('/home/sise/sda/gyj/NM/openssl_increase/common')
import data
import models
import utils
from utils import DupStdoutFileManager

from config import parse_encoder
# from test import validation

seed = 2
np.random.seed(seed)
torch.random.manual_seed(seed)

def build_model(args):
    model = models.OrderEmbedder(args)
    model.to(utils.get_device())
    return model


def validation(args, model, data_source):
    all_raw_preds, all_preds, all_labels = [], [], []
    loaders = data_source.gen_data_loaders(10 * args.batch_size, args.batch_size)
    for batch_i in loaders:
        ganchor, gtest, label = data_source.gen_batch(batch_i, False, 0)
        labels = [1 if l == 0 else 0 for l in label]
        labels = torch.tensor(labels).to(utils.get_device()) 
        with torch.no_grad():
            emb_ganchor, emb_gtest = (model.emb_model(ganchor), model.emb_model(gtest))
        raw_pred = model.predict(emb_ganchor, emb_gtest)
        # pred = torch.tensor([0 if p>args.margin else 1 for p in raw_pred]).to(utils.get_device()) 
        pred = model.clf_model(raw_pred.unsqueeze(1)).argmax(dim=-1)
        all_raw_preds.append(raw_pred)
        all_preds.append(pred)
        all_labels.append(labels)
    pred = torch.cat(all_preds, dim=-1)
    labels = torch.cat(all_labels, dim=-1)
    raw_pred = torch.cat(all_raw_preds, dim=-1)
    acc = torch.mean((pred == labels).type(torch.float))
    prec = (torch.sum(pred * labels).item() / torch.sum(pred).item() if
        torch.sum(pred) > 0 else float("NaN"))
    recall = (torch.sum(pred * labels).item() /
        torch.sum(labels).item() if torch.sum(labels) > 0 else
        float("NaN"))
    labels = labels.detach().cpu().numpy()
    raw_pred = raw_pred.detach().cpu().numpy()
    pred = pred.detach().cpu().numpy()
    auroc = roc_auc_score(labels, raw_pred)
    avg_prec = average_precision_score(labels, raw_pred)
    tn, fp, fn, tp = confusion_matrix(labels, pred).ravel()

    print("Validation. Acc: {:.4f}. "
        "P: {:.4f}. R: {:.4f}. AUROC: {:.4f}. AP: {:.4f}. TN: {}. FP: {}. FN: {}. TP: {}".format(
            acc, prec, recall, auroc, avg_prec,
            tn, fp, fn, tp))
    print("{}\n".format(str(datetime.now())))


def train_loop(args):
    if not os.path.exists(os.path.dirname(args.model_path)):
        os.makedirs(os.path.dirname(args.model_path))

    record_keys = ["conv_type", "n_layers", "hidden_dim", "margin", "batch_size", "n_batches"]
    args_str = ".".join(["{}={}".format(k, v)
        for k, v in sorted(vars(args).items()) if k in record_keys])
    print(args_str)
    model_path = '/home/sise/sda/gyj/NM/openssl_increase/ckpt/params_035_39l_3-128.pt'
    model = build_model(args)
    model.load_state_dict(torch.load(model_path))
    model.clf_model.train()
    clf_optimizer = optim.Adam(model.clf_model.parameters(), lr=0.01)
    batch_n = 0
    datasource = pkl.load(open('/home/sise/sda/gyj/NM/openssl_increase/data/sampledict.pkl', 'rb'))
    vdatasource = pkl.load(open('/home/sise/sda/gyj/NM/data/sampledict4.pkl', 'rb'))
    vdata_source = data.DiskDataSource(data.load_dataset(vdatasource))

    # for nodenum in range(5, 40):
    data_source = data.DiskDataSource(datasource)
    for _ in range(10):
        loaders = data_source.gen_data_loaders(500 * args.batch_size, args.batch_size)
        train_loss,  train_acc = 0, 0
        pbar = tqdm(loaders)
        for batch_i in pbar:
            pbar.set_description("Loss: {:.7f}. Training acc: {:.4f}".format(train_loss,  train_acc))
            s, pos1, pos2, neg1, neg2 = data_source.gen_clf_batch(batch_i, True)
            emb_s = model.emb_model(s)
            emb_pos1 = model.emb_model(pos1)
            emb_pos2 = model.emb_model(pos2)
            emb_neg1 = model.emb_model(neg1)
            emb_neg2 = model.emb_model(neg2)

            with torch.no_grad():
                predp1 = model.predict(emb_s, emb_pos1)
                predp2 = model.predict(emb_s, emb_pos2)
                predn1 = model.predict(emb_s, emb_neg1)
                predn2 = model.predict(emb_s, emb_neg2)
            labels = torch.tensor([1] * batch_i * 2 + [0] * batch_i * 2).to(utils.get_device()) 
            clf_optimizer.zero_grad()
            pred = torch.cat([predp1, predp2, predn1, predn2], dim=-1)
            pred = model.clf_model(pred.unsqueeze(1))
            clf_loss = nn.NLLLoss()(pred, labels)
            clf_loss.backward()
            clf_optimizer.step()

            pred = pred.argmax(dim=-1)
            # pred = torch.tensor([0 if p>args.margin else 1 for p in pred]).to(utils.get_device()) 
            acc = torch.mean((pred == labels).type(torch.float))
            train_loss = clf_loss.item()
            train_acc = acc.item()
            batch_n += 1
        print("Batch {}. Loss: {:.7f}. Training acc: {:.4f}".format(batch_n, train_loss, train_acc), end="\r")
        model.eval()
        validation(args, model, vdata_source)
        # if batch_n % 500 == 0:
    print('save')
    torch.save(model.state_dict(), '/home/sise/sda/gyj/NM/openssl_increase/ckpt/params_3-128.pt')


if __name__ == '__main__':
    parser = (argparse.ArgumentParser(description='Order embedding arguments'))
    utils.parse_optimizer(parser)
    parse_encoder(parser)
    args = parser.parse_args()
    now_time = datetime.now().strftime('%Y-%m-%d-%H-%M-%S')
    with DupStdoutFileManager('/home/sise/sda/gyj/NM/openssl_increase/runs/trainclf-' + now_time + '.log') as _:
        train_loop(args)
