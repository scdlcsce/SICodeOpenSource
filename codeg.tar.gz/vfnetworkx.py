import argparse
from config import parse_encoder
from gutils import g_sample
import utils
from tqdm import tqdm
import os
from tqdm import tqdm
import pickle as pkl
import numpy as np
import time
import  torch
import argparse
import  numpy as np
from config import parse_encoder
# from modeldata import DiskDataSource
import models
import utils
from tqdm import tqdm
import numpy as np
from tqdm import tqdm
import pickle as pkl
import networkx as nx
from networkx.algorithms.isomorphism.isomorphvf2 import GraphMatcher

input_dim = 500
wvec_dim = 476
opr_dim = 22

seed = 123
np.random.seed(seed)
torch.random.manual_seed(seed)


with open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/kernel_cluster_476-wv.txt', 'r') as fp:
    targetdict = eval(fp.read())

with open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/funccobert_cluster_76-ft.txt', 'r') as fp:
    seeddict = eval(fp.read())

def build_model(args):
    model = models.OrderEmbedder(args)
    model.to(utils.get_device())
    return model

seed = 123
np.random.seed(seed)
torch.random.manual_seed(seed)

code2type = { 
    '<operator>.plus':                          0,
    '<operator>.addition':                      0,
    '<operator>.subtraction':                   1,
    '<operator>.multiplication':                2,
    '<operator>.division':                      3,
    '<operator>.modulo':                        4,
    '<operator>.or':                           5,
    '<operator>.and':                           6,
    '<operator>.not':                           7,
    '<operator>.shiftRight':                    8,
    '<operators>.LogicalShifRight':             8,
    '<operator>.arithmeticShiftRight':          8,
    '<operator>.arithmeticShiftLeft':           8,
    '<operator>.shiftLeft':                     8,
    '<operator>.equals':                        9,
    '<operator>.notEquals':                     10,
    '<operator>.lessEqualsThan':                11,
    '<operator>.lessThan':                      11,
    '<operator>.greaterEqualsThan':             12,
    '<operator>.greaterThan':                   12,
    '<operator>.logicalNot':                    13,
    '<operator>.logicalOr':                     14,
    '<operator>.logicalAnd':                    15,
    '<operator>.sizeOf':                        16,
    '<operator>.addressOf':                     17,
    # --- drop ---
    '<operator>.minus':                         18, 
    '<operator>.cast':                          19,
    '<operator>.indirectMemberAccess':          20,          
    '<operator>.computedMemberAccess':          20,
    '<operator>.indirection':                   20,
    '<operator>.memberAccess':                  20,
    '<operator>.assignment':                    21,
}

def g2feats(g, ldict):
    feat = np.zeros(input_dim)
    gnode = list(g.nodes())
    for n in gnode:
        callstm = g.nodes()[n]["stm"]
        calltype = g.nodes()[n]["type"]
        if calltype == 'api':
            try:
                label = ldict[callstm]
            except Exception:
                label = input_dim - 1
            gvec = label
        elif calltype == 'opr':
            label = code2type[callstm]
            gvec = wvec_dim + label
        elif calltype == 'return': 
            gvec = input_dim - 2
        elif calltype == 'block':
            gvec = input_dim - 1
        feat[gvec] += 1
        g.nodes()[n]['label'] = gvec
    for e in list(g.edges()):
        del g.edges()[e]['type']

    return feat, g

if __name__ == "__main__":
    print(time.time())
    parser = (argparse.ArgumentParser(description='Order embedding arguments'))
    utils.parse_optimizer(parser)
    parse_encoder(parser)
    args = parser.parse_args()
    pdg_path = '/home/sise/sda/gyj/NM/graphdomain_openssl/data/kernel_code/pdg/'
    funnames = [ p for p in list(os.walk(pdg_path))[0][2] if '.pkl' in p]
    seedg = pkl.load(open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/ndef_prefix-noremove.pkl', 'rb'))
    r1, r2 = g2feats(seedg, seeddict)
    seedg = nx.Graph()
    for n in r2.nodes():
        seedg.add_node(n, label=r2.nodes()[n]['label'])
    for e in r2.edges():
        seedg.add_edge(e[0], e[1])

    emb_S_list = []
    namelist_list = []
    featslist_list = []
    results = []
    print(len(funnames) // 500)
    for i in range(len(funnames) // 500 + 1):
        beginidx = 500 * i
        namelist = []
        featslist = []
        encg = []
        for j in range(beginidx, min(beginidx + 500, len(funnames))):
        # for j in tqdm(range(beginidx, min(beginidx + 100, len(funnames)))):
            fname = funnames[j]
            pgraph = pkl.load(open(pdg_path+fname, 'rb'))
            for n in list(pgraph.nodes()):
                if 'MethodReturn' in n or 'Method' in n:
                    pgraph.remove_node(n)
            apilist = [ni for ni in list(pgraph.nodes()) if pgraph.nodes()[ni]['type'] == 'api']
            for n in apilist:
                # subc = g_sample_group(pgraph ,n, 4, ast)
                subc = g_sample(pgraph ,n, 4)
                if subc == None:
                    continue
                # subc = removeassign(subc) # pdg4
                if len(list(subc.edges())) == 0:
                    continue
                if len(list(subc.nodes())) < 3:
                    continue
                # subgraphlist.append(subc)
                # lenlist.append(len(list(subc.nodes())))
                r1, r2 = g2feats(subc, targetdict)
                g = nx.Graph()
                for n in r2.nodes():
                    g.add_node(n, label=r2.nodes()[n]['label'])
                for e in r2.edges():
                    g.add_edge(e[0], e[1])
                namelist.append(fname[:-4]+'_'+n)
                featslist.append(r1)
                encg.append(g)

        print('vf start: ', time.time())
        for idxi, engi in enumerate(encg):
            if GraphMatcher(engi, seedg).subgraph_is_isomorphic():
            # if DiGraphMatcher(engi, seed, node_match=lambda a,b: a['label'] == b['label']).subgraph_is_isomorphic():
                results.append(namelist[idxi])
        print('vf end: ', time.time())

        


    # print(time.time())
    # print(len(emb_S_list))
    # print(len(namelist_list))
    # print(len(featslist_list))
    # path = '/home/sise/sda/gyj/NM/graphdomain_openssl/data/kernel_code/emb-subgraph-noremove.pkl'
    # print(path)
    # pkl.dump([namelist_list, namelist_list, featslist_list], open(path, 'wb'))
