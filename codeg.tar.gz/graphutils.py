import  torch
from    torch import nn
from    torch.nn import functional as F
import sys
import networkx as nx
import random as rd
import numpy as np
import copy
from itertools import chain

def e_loss_pos(x1 ,x2):
    x = F.relu(x2 - x1)
    loss = torch.sum(x*x)
    return loss

def e_loss_neg(x1 ,x2, alpha):
    x = F.relu(x2 - x1)
    loss = torch.sum(x*x,dim=-1)
    loss = F.relu(alpha - loss)
    loss = torch.sum(loss)
    return loss

def e_loss_tri(x1 ,x2, xp, beta):
    loss1 = torch.sum(F.relu(xp - x1)*F.relu(xp - x1),dim=-1)
    loss2 = torch.sum(F.relu(xp - x2)*F.relu(xp - x2),dim=-1)
    loss = F.relu(beta + loss1 - loss2)
    # loss = F.relu(beta - loss1 + loss2)
    loss = torch.sum(loss)
    return loss


class DupStdoutFileWriter(object):
    def __init__(self, stdout, path, mode):
        self.path = path
        self._content = ''
        self._stdout = stdout
        self._file = open(path, mode)

    def write(self, msg):
        while '\n' in msg:
            pos = msg.find('\n')
            self._content += msg[:pos + 1]
            self.flush()
            msg = msg[pos + 1:]
        self._content += msg
        if len(self._content) > 1000:
            self.flush()

    def flush(self):
        self._stdout.write(self._content)
        self._stdout.flush()
        self._file.write(self._content)
        self._file.flush()
        self._content = ''

    def __del__(self):
        self._file.close()


class DupStdoutFileManager(object):
    def __init__(self, path, mode='w+'):
        self.path = path
        self.mode = mode

    def __enter__(self):
        self._stdout = sys.stdout
        self._file = DupStdoutFileWriter(self._stdout, self.path, self.mode)
        sys.stdout = self._file

    def __exit__(self, exc_type, exc_value, traceback):
        sys.stdout = self._stdout


codetype = [ 
    '<operator>.assignment',
    '<operator>.assignmentPlus',
    '<operator>.assignmentMultiplication',
    '<operator>.assignmentDivision',
    '<operator>.assignmentMinus',
    '<operators>.assignmentAnd',
    '<operator>.assignmentAnd',
    '<operators>.assignmentOr',
    '<operators>.assignmentXor',
    '<operators>.assignmentModulo',
    '<operators>.assignmentExponentiation',
    '<operators>.assignmentArithmeticShiftRight',
    '<operators>.LogicalShifRight',
    '<operators>.assignmentShiftLeft',
    '<operator>.logicalNot',
    '<operator>.logicalOr',
    '<operator>.logicalAnd',
    '<operator>.equals',
    '<operator>.notEquals',
    '<operator>.indirectMemberAccess',
    '<operator>.computedMemberAccess',
    '<operator>.addressOf',
    '<operator>.cast',
    '<operator>.conditionalExpression',
    '<operator>.postIncrement',
    '<operator>.preIncrement',
    '<operator>.postDecrement',
    '<operator>.preDecrement',
    '<operator>.or',
    '<operator>.and',
    '<operator>.addition',
    '<operator>.subtraction',
    '<operator>.multiplication',
    '<operator>.division',
    '<operator>.modulo',
    '<operator>.minus',
    '<operator>.plus',
    '<operator>.not',
    '<operator>.arithmeticShiftRight',
    '<operator>.arithmeticShiftLeft',
    '<operator>.lessEqualsThan',
    '<operator>.greaterEqualsThan',
    '<operator>.lessThan',
    '<operator>.greaterThan',
    '<operator>.indirection',
    '<operator>.memberAccess',
    '<operator>.sizeOf',
    '<operator>.shiftLeft',
    '<operator>.shiftRight']

assigntype = {
    '<operator>.assignmentPlus': '<operator>.plus',
    '<operator>.assignmentMultiplication': '<operator>.multiplication',
    '<operator>.assignmentDivision':'<operator>.division',
    '<operator>.assignmentMinus':'<operator>.minus',
    '<operators>.assignmentAnd':'<operator>.and',
    '<operator>.assignmentAnd':'<operator>.and',
    '<operators>.assignmentOr':'<operator>.or',
    '<operators>.assignmentXor':'<operator>.or',
    '<operators>.assignmentModulo':'<operator>.modulo',
    '<operators>.assignmentExponentiation':'<operator>.exponentiation',
    '<operators>.assignmentArithmeticShiftRight':'<operator>.arithmeticShiftRight',
    '<operators>.assignmentShiftLeft': '<operators>.LogicalShifRight',
    '<operator>.postIncrement':'<operator>.plus',
    '<operator>.preIncrement':'<operator>.plus',
    '<operator>.postDecrement':'<operator>.minus',
    '<operator>.preDecrement':'<operator>.minus'}


def makeBlock(g):
    nlist = list(g.nodes())
    for n in nlist:
        if not ('Call@' in n or 'Return@' in n):
            pre = list(g.predecessors(n))
            suc = list(g.successors(n))
            for p in pre:
                for s in suc:
                    g.add_edge(p,s)
            g.remove_node(n)
    return g


def normGraph(g):
    for n in list(g.nodes()):
        try:
            pdict = g.nodes()[n]['property']
        except:
            g.nodes()[n]['line'] = []
            g.nodes()[n]['type'] = []
            continue
        g.nodes()[n]['line'] = pdict['LINE_NUMBER']
        if 'Return@' in n:
            g.nodes()[n]['type'] = 'return'
            g.nodes()[n]['stm'] = 'return'
            g.nodes()[n].pop('property')
            continue
        if 'Unknown@' in n:
            g.nodes()[n]['type'] = 'unknown'
            g.nodes()[n]['stm'] = 'unknown'
            g.nodes()[n].pop('property')
            continue
        stm = pdict['NAME']
        if not stm in codetype:
            g.nodes()[n]['type'] = 'api'
            fname = stm.lower().strip()
            if '()' in fname:
                fname = fname.replace('()','')
            if '->' in fname:
                fname = fname.split('->')[-1]
            if '.' in fname:
                fname = fname.split('.')[-1]
            if ')' in fname:
                fname = fname.replace(')','')
            if '(' in fname:
                fname = fname.split('(')[0]
            if '~' in fname:
                fname = fname.split('~')[1]
            if ',' in fname:
                fname = fname.split(',')[0].strip()
            if '[' in fname:
                fname = fname.split('[')[0].strip()
            g.nodes()[n]['stm'] = fname
        else:
            g.nodes()[n]['type'] = 'opr'
            g.nodes()[n]['stm'] = stm
        g.nodes()[n].pop('property')
    nlist = list(g.nodes())
    for n in nlist:
        if 'MethodReturn@' in n:
            g.add_node('MethodReturn')
            g.nodes()['MethodReturn']['line'] = '-1'
            g.nodes()['MethodReturn']['type'] = 'methodreturn'
            g.nodes()['MethodReturn']['stm'] = 'methodreturn'
            pre = list(g.predecessors(n))
            for p in pre:
                g.add_edge(p,'MethodReturn')
            g.remove_node(n)
            continue
        if g.nodes()[n]['stm'] == '<operator>.conditionalExpression':
            g.nodes()[n]['stm'] = '<operator>.assignment'
            continue
        if g.nodes()[n]['stm'] in assigntype:
            stm1 = '<operator>.assignment'
            stm2 = assigntype[g.nodes()[n]['stm']]
            l = g.nodes()[n]['line']
            t = 'opr'
            g.add_node(n+'_p', line = l,type = t,stm = stm1)
            g.add_node(n+'_s', line = l,type = t,stm = stm2)
            g.add_edge(n+'_p',n+'_s')
            pre = list(g.predecessors(n))
            suc = list(g.successors(n))
            for p in pre:
                g.add_edge(p,n+'_p')
            for s in suc:
                g.add_edge(n+'_s',s)
            g.remove_node(n)
    nlist = list(g.nodes())
    for n in nlist:
        if g.nodes()[n]['stm'] == '<operator>.assignment':
            pre = list(g.predecessors(n))
            suc = list(g.successors(n))
            for p in pre:
                for s in suc:
                    g.add_edge(p,s)
            g.remove_node(n)
    # zeropre = []
    # nlist = list(g.nodes())
    # # for n in nlist:
    # #     if len(list(g.predecessors(n))) == 0:
    # #         zeropre.append(n)
    # # g.add_node('Entrance')
    # # g.nodes()['Entrance']['line'] = '0'
    # # g.nodes()['Entrance']['type'] = 'entrance'
    # # g.nodes()['Entrance']['stm'] = 'entrance'
    # # for s in zeropre:
    # #     g.add_edge('Entrance', s)
    return g

def getgraph(funcname, funccfg, funcpdg):
    cfg = nx.DiGraph()
    pdg = nx.DiGraph()
    cfg.name = funcname
    pdg.name = funcname
    for c in funccfg:
        prop = c['properties']
        propdict = dict()
        for pp in prop:
            propdict[pp['key']] = pp['value']
        cfg.add_node(c['id'].split('.')[-1], property=propdict)
        pdg.add_node(c['id'].split('.')[-1], property=propdict)
        for e in c['edges']:
            cfg.add_edge(e['out'].split('.')[-1], e['in'].split('.')[-1])
    for c in funcpdg:
        for e in c['edges']:
            if not (('Return' in e['out'] or 'Return' in e['in']) and ('ReachingDef' in e['id'])): 
                pdg.add_edge(e['out'].split('.')[-1], e['in'].split('.')[-1])
    nlist = list(cfg.nodes())
    for n in nlist:
        if 'MethodReturn' in n:
            try:
                # cfg.remove_node(n)
                pdg.remove_node(n)
            except:
                pass
    # if len(nlist) > MAXRE:
    return cfg, pdg
        

code2type = { 
    '<operator>.plus':                          1,
    '<operator>.addition':                      1,
    '<operator>.minus':                         2,
    '<operator>.subtraction':                   2,
    '<operator>.multiplication':                3,
    '<operator>.division':                      4,
    '<operator>.modulo':                        5,
    '<operator>.or':                            6,
    '<operator>.and':                           7,
    '<operator>.not':                           8,
    '<operator>.shiftRight':                    9,
    '<operators>.LogicalShifRight':             9,
    '<operator>.arithmeticShiftRight':          9,
    '<operator>.arithmeticShiftLeft':           10,
    '<operator>.shiftLeft':                     10,
    '<operator>.equals':                        11,
    '<operator>.notEquals':                     12,
    '<operator>.lessEqualsThan':                13,
    '<operator>.greaterEqualsThan':             14,
    '<operator>.lessThan':                      15,
    '<operator>.greaterThan':                   16,
    '<operator>.logicalNot':                    17,
    '<operator>.logicalOr':                     18,
    '<operator>.logicalAnd':                    19,
    '<operator>.indirectMemberAccess':          20,
    '<operator>.computedMemberAccess':          20,
    '<operator>.indirection':                   20,
    '<operator>.memberAccess':                  20,
    '<operator>.sizeOf':                        21,
    '<operator>.addressOf':                     22,
    '<operator>.cast':                          23,
    '<operator>.assignment':                    24,
}



def g2input(g, ldict, input_dim, wvec_dim):
    gnode = list(g.nodes())
    num_nodes = len(gnode)
    gadj = np.zeros((num_nodes, num_nodes))
    gvec = np.zeros((num_nodes, input_dim))
    g = g.to_undirected()
    for i, n in enumerate(gnode):
        neighbors = list(nx.all_neighbors(g, n))
        for nn in neighbors:
            j = gnode.index(nn)
            gadj[i][j] = 1
            gadj[j][i] = 1     
    
    for i, n in enumerate(gnode):
        try:
            callstm = g.nodes()[n]["stm"]
            calltype = g.nodes()[n]["type"]
        except KeyError:
            gvec[i][wvec_dim] = 1
            continue
        if calltype == 'api':
            try:
                label = ldict[callstm]
                gvec[i][label - 1] = 1
            except KeyError:
                gvec[i][wvec_dim] = 1
                pass
        elif calltype == 'opr':
            label = code2type[callstm]
            gvec[i][wvec_dim + label] = 1
        else: 
            gvec[i][input_dim-1] = 1
    ori_feature = np.sum(gvec,axis=0)
    return gadj, gvec, num_nodes, ori_feature


def g2input_rand(g, ldict, input_dim, wvec_dim):
    gnode = list(g.nodes())
    num_nodes = len(gnode)
    gadj = np.zeros((num_nodes, num_nodes))
    gvec = np.zeros((num_nodes, input_dim))
    g = g.to_undirected()
    for i, n in enumerate(gnode):
        neighbors = list(nx.all_neighbors(g, n))
        for nn in neighbors:
            j = gnode.index(nn)
            gadj[i][j] = 1
            gadj[j][i] = 1     
    
    randlist = list(range(len(gnode)))
    rd.shuffle(randlist)
    randlist = randlist[:int(len(gnode)*0.5)]
    for i, n in enumerate(gnode):
        try:
            callstm = g.nodes()[n]["stm"]
            calltype = g.nodes()[n]["type"]
        except KeyError:
            gvec[i][wvec_dim] = 1
            continue
        if i in randlist:
            randft = rd.choice(range(input_dim))
            gvec[i][randft] = 1
        elif calltype == 'api':
            try:
                label = ldict[callstm]
                gvec[i][label - 1] = 1
            except KeyError:
                gvec[i][wvec_dim] = 1
                pass
        elif calltype == 'opr':
            label = code2type[callstm]
            gvec[i][wvec_dim + label] = 1
        else: 
            gvec[i][input_dim-1] = 1
        
    ori_feature = np.sum(gvec,axis=0)
    return gadj, gvec, num_nodes, ori_feature



# def forward(g, n, hopsize):
#     count = 0
#     while count < hopsize :
#         count += 1
#         suc = []
#         for ni in n:
#             suc += list(g.successors(ni))
#         newnode = []
#         for s in suc:
#            if not s in n:
#                 newnode.append(s)
#         if len(newnode) == 0:
#             break
#         n += newnode
#     return n


# def backward(bbg, n, hopsize):
#     count = 0
#     while count < hopsize:
#         count += 1
#         pre = []
#         for ni in n:
#             pre += list(bbg.predecessors(ni))
#         newnode = []
#         for p in pre:
#             if not p in n:
#                 newnode.append(p)
#         if len(newnode) == 0:
#             break
#         n += newnode
#     return n


# def g_sample(tgraph, n, hopsize):
#     gnode = [n]
#     gnode += forward(tgraph, [n], hopsize)
#     gnode += backward(tgraph, [n], hopsize)
#     gnode = list(set(gnode))
#     gs = tgraph.subgraph(gnode)
#     mapping = {n:'CENTER_NODE'}
#     gs = nx.relabel_nodes(gs, mapping)
#     if len(gs.nodes()) == 0:
#         raise ValueError
#     return gs, gnode


def pos_large_sample(gnode, tgraph, n, hopsize):
    if len(gnode)<=1 + hopsize:
        raise ValueError
    count = 0
    while(count < 10):
        count += 1
        p_gnode = copy.deepcopy(gnode)
        p_gnode.remove(n)
        rnode = rd.choice(p_gnode)
        p_gnode.remove(rnode)
        p_gnode.append(n)
        g = tgraph.subgraph(p_gnode)
        g = g.to_undirected()
        largestcc = max(nx.connected_components(g), key=len)
        if len(largestcc) > 1:
            gp = tgraph.subgraph(largestcc)
            mapping = {n:'CENTER_NODE'}
            gp = nx.relabel_nodes(gp, mapping)
            if not 'CENTER_NODE' in list(gp.nodes()):
                continue
            return gp
    raise ValueError

def pos_small_sample(gnode, tgraph, n, hopsize):
    if len(gnode)<=1 + hopsize:
        raise ValueError
    count = 0
    while(count < 10):
        count += 1
        p_gnode = copy.deepcopy(gnode)
        p_gnode.remove('CENTER_NODE')
        rnode = rd.choice(p_gnode)
        p_gnode.remove(rnode)
        p_gnode.append(n)
        g = tgraph.subgraph(p_gnode)
        g = g.to_undirected()
        largestcc = max(nx.connected_components(g), key=len)
        if len(largestcc) > 1:
            gp = tgraph.subgraph(largestcc)
            mapping = {n:'CENTER_NODE'}
            gp = nx.relabel_nodes(gp, mapping)
            if not 'CENTER_NODE' in list(gp.nodes()):
                continue
            return gp
    raise ValueError


def diff_sample(tgraph, n, gnode):
    added = 0
    gn2 = tgraph.subgraph(gnode)
    gn2 = gn2.to_undirected()
    mapping = {n:'CENTER_NODE'}
    gn2 = nx.relabel_nodes(gn2, mapping)
    for u in gnode:
        if added > 0:
            break
        for v in gnode:
            if not u == v:
                if not gn2.has_edge(u,v):
                    gn2.add_edge(u,v)
                    added = 1
                    break
    if added == 0:
        raise ValueError
    return gn2


def neg_sample(tgraph, n, o_gnode, hopsize):
    n_gn = list(tgraph.nodes())
    n_gnode = []
    for ni in n_gn:
        if tgraph.nodes()[ni]['type'] == 'api':
            n_gnode.append(ni)
    n_gnode.remove(n)
    rd.shuffle(n_gnode)
    found = 0
    for centernode in n_gnode:
        gn_node = []
        gn_node += forward(tgraph, [centernode], hopsize)
        gn_node += backward(tgraph, [centernode], hopsize)
        gn_node = list(set(gn_node))
        if len(set(gn_node) - set(o_gnode)) > 0:
            found = 1
            break
    if found == 0:  
        raise ValueError
    gn1 = tgraph.subgraph(gn_node)
    mapping = {centernode:'CENTER_NODE'}
    gn1 = nx.relabel_nodes(gn1, mapping)
    if len(gn1.nodes()) == 0:
        raise ValueError
    return gn1

# --------------------

def forward(bbg, n, hopsize):
    count = 0
    sucedge  = []
    while count < hopsize :
        count += 1
        suc = []
        for ni in n:
            suc += list(bbg.successors(ni))
            sucedge += [(ni, s) for s in list(bbg.successors(ni))]
        newnode = []
        for s in suc:
           if not s in n:
                newnode.append(s)
        if len(newnode) == 0:
            break
        n += newnode
    return n[1:], sucedge


def backward(bbg, n, hopsize):
    count = 0
    preedge  = []
    while count < hopsize:
        count += 1
        pre = []
        for ni in n:
            pre += list(bbg.predecessors(ni))
            preedge += [(p, ni) for p in list(bbg.predecessors(ni))]
        newnode = []
        for p in pre:
            if not p in n:
                newnode.append(p)
        if len(newnode) == 0:
            break
        n += newnode
    return n[1:], preedge

def g_sample(tgraph, n, hopsize):
    nsus, edgesus = forward(tgraph, [n], hopsize)
    npre, edgepre = backward(tgraph, [n], hopsize)
    gnode = [n] + list(chain(*zip([npre[i] for i in range(min(len(nsus), len(npre)))],[nsus[j] for j in range(min(len(nsus), len(npre)))]))) + npre[min(len(nsus), len(npre)):] + nsus[min(len(nsus), len(npre)):]
    nl = sorted(set(gnode), key=gnode.index)
    gedge = edgepre + edgesus
    adj = []
    for idxi, i in enumerate(nl):
        for idxj, j in enumerate(nl):
            if (i,j) in gedge:
                adj.append(str([idxi,idxj]))
                adj.append(str([idxj,idxi]))
    return [len(nl), sorted(list(set(adj)))]

def g_feature_sample(tgraph, n, hopsize):
    nsus, edgesus = forward(tgraph, [n], hopsize)
    npre, edgepre = backward(tgraph, [n], hopsize)
    gnode = [n] + list(chain(*zip([npre[i] for i in range(min(len(nsus), len(npre)))],[nsus[j] for j in range(min(len(nsus), len(npre)))]))) + npre[min(len(nsus), len(npre)):] + nsus[min(len(nsus), len(npre)):]
    nl = sorted(set(gnode), key=gnode.index)
    gedge = edgepre + edgesus
    return nl, gedge


def g2inputg(gnode, gedges, tgraph, ldict, input_dim, wvec_dim):
    sg = nx.Graph()
    feat = np.zeros(input_dim)
    # gnode = list(g.nodes())
    for idxn, n in enumerate(gnode):
        gvec = wvec_dim
        try:
            callstm = tgraph.nodes()[n]["stm"]
            calltype = tgraph.nodes()[n]["type"]
            if calltype == 'api':
                label = ldict[callstm]
                gvec = label - 1
            elif calltype == 'opr':
                label = code2type[callstm]
                gvec = wvec_dim + label
            else: 
                gvec = input_dim-1
        except KeyError:
            pass
        sg.add_node('n'+str(idxn), label = gvec)
        
    # g = g.to_undirected()
    for e in gedges:
        sg.add_edge('n'+str(gnode.index(e[0])), 'n'+str(gnode.index(e[1])))

    for n in list(sg.nodes()):
        f = sg.nodes()[n]['label']
        feat[f] += 1
    return sg, feat
