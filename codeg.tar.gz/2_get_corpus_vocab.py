import networkx as nx
import os
from tqdm import tqdm
import random as rd
import pickle as pkl
from copy import deepcopy


def get_path(g):
    g_t = deepcopy(g)
    for e in list(g_t.edges()):
        try:
            if int(g_t.nodes()[e[0]]['line']) > int(g_t.nodes()[e[1]]['line']):
                g_t.remove_edge(e[0], e[1])
        except KeyError:
            pass
        except TypeError:
            pass
    pkl.dump(g_t, open('/home/sise/sda/gyj/NM/graphdomain_openssl/pdg.pkl', 'wb'))
    
    startnode = [n for n in g_t.nodes() if 'Method@' in n]
    if startnode == []:
        return None
    else:
        startnode = startnode[0]

    path = [startnode]
    curnode = startnode
    removelist = []
    for _ in range(1000):
        try:
            if len(list(g_t.successors(curnode))) == 0:
                break
        except:
            break
        slist = list(g_t.successors(curnode))
        curnode = rd.choice(slist)
        path.append(curnode)
        if curnode in path[:-1]:
            print('d')
            idx = path[:-1].index(curnode)
            for nodeidx in range(idx,len(path)-1):
                if len(list(g_t.successors(path[nodeidx]))) >1 :
                    e = (path[nodeidx],path[nodeidx+1])
                    if e in removelist:
                        break
                    g.remove_edge(e[0],e[1])
                    removelist.append((path[nodeidx],path[nodeidx+1]))
                    break
    pkl.dump(g_t, open('/home/sise/sda/gyj/NM/graphdomain_openssl/pdg2.pkl', 'wb'))
    funcpath = []
    for i in path[1:]:
        try:
            if g.nodes()[i]['type'] == 'api':
                funcpath.append(g.nodes()[i]['stm'].strip())
        except:
            continue
    if len(funcpath)>2:
        funcpath = ' '.join(funcpath)
    else:
        funcpath = None
    return funcpath


if __name__ == "__main__":
    datadir = '/home/sise/sda/gyj/NM/graphdomain_openssl/data/pdg/'
    corpus = []
    f = os.walk(datadir)
    filenames = [p for p in list(list(f)[0][2]) if 'pkl' in p]
    allapis = []

    for f in tqdm(filenames):
    # g = pkl.load(open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/pdg/172__ossl_pkcs7_resolve_libctx.pkl', 'rb'))
        g = pkl.load(open(datadir + f, 'rb'))
        cfg = nx.DiGraph()
        for n in g.nodes():
            if 'MethodReturn' in n:
                continue
            cfg.add_node(n, stm = g.nodes()[n]['stm'], line = g.nodes()[n]['line'], type = g.nodes()[n]['type'])
            if g.nodes()[n]['type'] == 'api':
                allapis.append(g.nodes()[n]['stm'].strip())
        for e in list(g.edges()):
            if 'cfg' in g.edges()[e]['type']:
                if 'MethodReturn' in e[0] or 'MethodReturn' in e[1]:
                    continue
                cfg.add_edge(e[0], e[1])
        
        for i in range(100):
            c = get_path(cfg)
            if not c ==None:
                corpus.append(c)
            
    corpus = list(set(corpus))

    with open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/openssl-corpus.txt','w')as fp:
        fp.writelines('\n'.join(corpus)[1:])
    with open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/openssl-corpus.txt','r') as fp1:
        corpus = fp1.readlines()
        vocab = []
        for c in corpus:
            cset = c.replace('\n','').split(' ')
            vocab += cset
        vocab = ['[UNK]','[PAD]','[SEP]','[CLS]','[MASK]'] + list(set(vocab)-set(['']))
        vocab = '\n'.join(vocab)
        with open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/openssl-vocab.txt','w') as fp2:
            fp2.write(vocab)

    allapis = list(set(allapis))
    with open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/openssl-allapi.txt','w') as fp2:
        fp2.write(str(allapis))