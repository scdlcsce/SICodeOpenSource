from gutils import seed2g, group_seed2g, getgraph, removeid, normgraph, removeassign
import json
import pickle as pkl
from makegroup import getlayer, getcompound

if __name__ == "__main__":

    seedfile = 's_server'
    seedfunc = 'www_body'
    vinfo = eval("[[2991,2992],'BIO_new']")
    # seedfile = 'asn1_par'
    # seedfunc = 'asn1_print_info'
    # vinfo = eval("[[44],'BIO_new']")
    # seedfile = 'bio_ndef'
    # seedfunc = 'ndef_prefix'
    # vinfo = eval("[[117,116],'OPENSSL_malloc']")


    vinfo = (vinfo[0], vinfo[1].lower())
    hopsize = 4

    with open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/funccobert_cluster_76-ft.txt', 'r') as fid:
        ldict = eval(fid.read())
    filedir='/home/sise/sda/gyj/NM/graphdomain_openssl/data/vul/'+seedfile

    with open(filedir+'_pdg.json','r') as fp:
        pdata = json.load(fp)

    funcpdg = None
    for f in pdata['functions']:
        if f['function'] == seedfunc:
            funcpdg = f['PDG']

    pdg = getgraph(seedfunc, funcpdg) # pdg1
    pdg = removeid(pdg) # pdg2
    pdg = normgraph(pdg) # pdg3
    for n in list(pdg.nodes()):
        if 'MethodReturn' in n or 'Method' in n:
            pdg.remove_node(n)
    with open(filedir+'.c.ast') as fp:
        astdata = fp.readlines()
    ast = []
    for lidx, l in enumerate(astdata):
        ltoken = l.split(':')
        if len(ltoken)<3:
            continue
        if l.split(':')[1] == 'FunctionDef':
            fname = l.split(':')[2].split(' ')[0]
            if not fname == seedfunc:
                continue
            compoundlayer = 1
            c_start = lidx+1
            compoundrange = getlayer(astdata, c_start, 1)
            ast = getcompound(astdata, (compoundrange[0]+1, compoundrange[1]), compoundlayer+1)

    _, g_seed = seed2g(pdg, vinfo[0], vinfo[1], hopsize)

    # _, g_seed = group_seed2g(pdg, vinfo[0], vinfo[1], hopsize, ast)
    # g_seed = removeassign(g_seed)

    pkl.dump(g_seed, open('/home/sise/sda/gyj/NM/graphdomain_openssl/data/'+seedfunc+'-noremove.pkl', 'wb'))